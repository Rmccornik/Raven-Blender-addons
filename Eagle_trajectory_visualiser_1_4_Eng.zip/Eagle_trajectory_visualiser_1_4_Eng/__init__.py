# ================================================================
#  JMK6 / Eagle Trajectory Visualizer  –  Blender Addon  v1.4
#  Author : rafal.karnicki@pwr.edu.pl + Claude Sonnet 4.6
#  Requires: Blender 4.x / 5.x
#  Tab:     "JMK6 Traj"
#
#  Changes v1.4:
#   [*] Full English translation of panel labels, buttons,
#       operator names and property descriptions
#  Changes v1.3:
#   [*] Updated default values:
#       IMU:   Rx= 90  Ry=  0  Rz=  0
#       Front: Rz=180  Rx=180  Ry=  0
#       Back:  Rz=  0  Rx=-180 Ry=  0
#       Left:  Rz=  0  Rx=  0  Ry=180
#       Right: Rz=  0  Rx=  0  Ry=180
#  Changes v1.2:
#   [1] Slider "Shift X/Y Scale" (0.00–1.00, default 0.10)
#       replaces Reset Shift button
#  Changes v1.1:
#   [1] Per-camera shift_x / shift_y sliders with live update
# ================================================================

bl_info = {
    "name":        "JMK6 Eagle Trajectory Visualizer",
    "author":      "rafal.karnicki@pwr.edu.pl + Claude Sonnet 4.6",
    "version":     (1, 4, 0),
    "blender":     (4, 0, 0),
    "location":    "View3D > Sidebar (N) > JMK6 Traj",
    "description": "Eagle scanner (JMK1) trajectory visualizer – 4 cameras",
    "category":    "Import-Export",
}

import bpy
import math
import os
import re
import json
import bisect
import shutil

from bpy.props import (
    StringProperty, IntProperty, FloatProperty,
    BoolProperty, PointerProperty,
)
from bpy.types import Panel, Operator, PropertyGroup
from mathutils import Vector, Quaternion, Matrix


# ════════════════════════════════════════════════════════════════
#  4-CAMERA CONFIGURATION
# ════════════════════════════════════════════════════════════════

SIDES = ['front', 'back', 'left', 'right']

CAM_CFG = {
    'front': dict(prefix='CAMF', cam_id=1, color=(0.0, 0.8,  0.0, 1.0)),
    'back':  dict(prefix='CAMB', cam_id=2, color=(0.8, 0.0,  0.0, 1.0)),
    'left':  dict(prefix='CAML', cam_id=3, color=(0.0, 0.4,  1.0, 1.0)),
    'right': dict(prefix='CAMR', cam_id=4, color=(1.0, 0.6,  0.0, 1.0)),
}

# ════════════════════════════════════════════════════════════════
#  BUILT-IN CALIBRATION  Eagle JMK1002804
# ════════════════════════════════════════════════════════════════

DEFAULT_CALIB = {
    'front': {
        'transform_matrix': [
            -0.00774480934707622,  -0.9999699012331831,  -0.00046320176551911674, -0.004307066236868099,
             0.5058762362445366,   -0.003518463573149111, -0.8625988952097877,    -0.0758637762944894,
             0.8625713022882453,   -0.0069149867521610675, 0.5058882598232323,    -0.015913668388664946,
             0.0, 0.0, 0.0, 1.0,
        ],
        'fx': 1131.6912098590117, 'fy': 1132.5541164979988,
        'cx': 2014.2763912539208, 'cy': 1512.833522976397,
        'imagewidth': 1000, 'imageheight': 750,
    },
    'back': {
        'transform_matrix': [
            -0.8579686145690899,   0.010576209527628184,  -0.5135932244553322,  -0.08800662777054377,
            -0.006260999705433503, -0.9999290688803928,   -0.010131983551137164, -0.009936678858975765,
            -0.5136639526938659,  -0.005477316863178477,   0.8579739755394066,  -0.004483744944565044,
             0.0, 0.0, 0.0, 1.0,
        ],
        'fx': 1137.5110672082633, 'fy': 1137.6607525654526,
        'cx': 1905.3316420011138, 'cy': 1620.1412873926597,
        'imagewidth': 1000, 'imageheight': 750,
    },
    'left': {
        'transform_matrix': [
             0.7457384280935071,  0.4997610436248995,  0.44058267798402645,  0.10010800636608194,
             0.5135485256846882, -0.009907647391985241,-0.858003350978444,   -0.01902473170463172,
            -0.42443151229816595, 0.8661066549785351,  -0.26404006054041207, -0.11028605113371866,
             0.0, 0.0, 0.0, 1.0,
        ],
        'fx': 1140.983481750628,  'fy': 1141.1708719257358,
        'cx': 1979.938101235466,  'cy': 1523.1564601572031,
        'imagewidth': 1000, 'imageheight': 750,
    },
    'right': {
        'transform_matrix': [
            -0.7327806843430777,  0.5213320577863332,  -0.43731608040175923, -0.09746764272201959,
             0.5090190256694587, -0.006544637208954374, -0.860730387072699,  -0.015478622856394293,
            -0.45158841898370855,-0.8533288072297047,   -0.26057215237189846, -0.10865464302158973,
             0.0, 0.0, 0.0, 1.0,
        ],
        'fx': 1137.2136989128942, 'fy': 1137.8719154491425,
        'cx': 2150.595598130165,  'cy': 1521.1652323522892,
        'imagewidth': 1000, 'imageheight': 750,
    },
}

_C_ROS2BL = Matrix((
    ( 1,  0,  0,  0),
    ( 0,  0,  1,  0),
    ( 0, -1,  0,  0),
    ( 0,  0,  0,  1),
))

CAMCONV = (Matrix.Rotation(math.radians(90),  4, 'X') @
           Matrix.Rotation(math.radians(180), 4, 'Y'))


# ════════════════════════════════════════════════════════════════
#  LIVE UPDATE CALLBACKS
# ════════════════════════════════════════════════════════════════

def _update_focal_length(self, context):
    fl       = self.cam_focal_length
    prefixes = tuple(cfg['prefix'] for cfg in CAM_CFG.values())
    for obj in bpy.data.objects:
        if obj.type == 'CAMERA' and obj.name.startswith(prefixes):
            obj.data.lens = fl


def _rebuild_cameras(props, side: str):
    cfg = CAM_CFG[side]
    rz  = getattr(props, f"cam_rz_{side}")
    rx  = getattr(props, f"cam_rx_{side}")
    ry  = getattr(props, f"cam_ry_{side}")
    for obj in bpy.data.objects:
        if obj.type != 'CAMERA' or not obj.name.startswith(cfg['prefix']):
            continue
        base_flat = obj.get('jmk6base_matrix')
        if base_flat is None:
            continue
        M_base = _list_to_matrix4x4(base_flat)
        obj.matrix_world = _apply_local_corrections(M_base, rz, rx, ry)


def _update_shift(props, side: str):
    cfg = CAM_CFG[side]
    sx  = getattr(props, f"cam_sx_{side}")
    sy  = getattr(props, f"cam_sy_{side}")
    for obj in bpy.data.objects:
        if obj.type == 'CAMERA' and obj.name.startswith(cfg['prefix']):
            obj.data.shift_x = sx
            obj.data.shift_y = sy


def _update_shift_scale(self, context):
    scale = self.cam_shift_scale
    for side in SIDES:
        sx0 = getattr(self, f"cam_sx0_{side}")
        sy0 = getattr(self, f"cam_sy0_{side}")
        setattr(self, f"cam_sx_{side}", sx0 * scale)
        setattr(self, f"cam_sy_{side}", sy0 * scale)
        _update_shift(self, side)


def _make_update(side):
    def _upd(self, context):
        _rebuild_cameras(self, side)
    return _upd


def _make_update_shift(side):
    def _upd(self, context):
        _update_shift(self, side)
    return _upd


# ════════════════════════════════════════════════════════════════
#  HELPERS
# ════════════════════════════════════════════════════════════════

def _list_to_matrix4x4(flat) -> Matrix:
    f = [float(v) for v in flat]
    return Matrix([f[0:4], f[4:8], f[8:12], f[12:16]])


def _base_matrix_to_list(M: Matrix):
    return [M[r][c] for r in range(4) for c in range(4)]


def _apply_local_corrections(M_base: Matrix, rz: float, rx: float, ry: float) -> Matrix:
    M = M_base.copy()
    if rz != 0.0:
        M = M @ Matrix.Rotation(math.radians(rz), 4, 'Z')
    if rx != 0.0:
        M = M @ Matrix.Rotation(math.radians(rx), 4, 'X')
    if ry != 0.0:
        M = M @ Matrix.Rotation(math.radians(ry), 4, 'Y')
    return M


def calib_to_shift(cx, cy, w, h):
    return cx / w - 0.5, 0.5 - cy / h


def get_or_create_collection(name: str) -> bpy.types.Collection:
    col = bpy.data.collections.get(name)
    if col is None:
        col = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(col)
    return col


def clear_collection(col: bpy.types.Collection):
    for obj in list(col.objects):
        bpy.data.objects.remove(obj, do_unlink=True)


# ════════════════════════════════════════════════════════════════
#  LOAD CALIBRATION
# ════════════════════════════════════════════════════════════════

def load_calib(filepath: str) -> dict:
    with open(filepath, 'r') as f:
        raw = json.load(f)
    result  = {}
    out     = raw.get('out_put', {})
    caminfo = raw.get('camera_info', {})
    for side in SIDES:
        entry = dict(DEFAULT_CALIB[side])
        if side in out:
            tm = out[side].get('transform_matrix', [])
            if tm and isinstance(tm[0], list):
                flat = [v for row in tm for v in row]
            else:
                flat = tm
            if len(flat) == 16:
                entry['transform_matrix'] = flat
        if side in caminfo:
            ci = caminfo[side]
            K  = ci.get('K', [])
            if len(K) >= 9:
                entry['fx'] = K[0]
                entry['fy'] = K[4]
                entry['cx'] = K[2]
                entry['cy'] = K[5]
        result[side] = entry
    return result


# ════════════════════════════════════════════════════════════════
#  TIMESTAMP PARSING
# ════════════════════════════════════════════════════════════════

_TS_RE = re.compile(r'(\d{10})[_.](\d{6})')

def parse_timestamp_from_name(filename: str):
    m = _TS_RE.search(filename)
    return float(f"{m.group(1)}.{m.group(2)}") if m else None


def collect_image_timestamps(folder: str) -> list:
    result = []
    if not folder or not os.path.isdir(folder):
        return result
    exts = {'.jpg', '.jpeg', '.png', '.tif', '.tiff'}
    for name in os.listdir(folder):
        if os.path.splitext(name)[1].lower() not in exts:
            continue
        ts = parse_timestamp_from_name(name)
        if ts is not None:
            result.append((ts, os.path.join(folder, name)))
    result.sort(key=lambda x: x[0])
    return result


# ════════════════════════════════════════════════════════════════
#  TRAJECTORY
# ════════════════════════════════════════════════════════════════

def load_trajectory(filepath: str, step: int = 1) -> list:
    records = []
    with open(filepath, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split()
            if len(parts) < 8:
                continue
            ts, tx, ty, tz, qx, qy, qz, qw = map(float, parts[:8])
            records.append({
                'ts':   ts,
                'pos':  Vector((tx, ty, tz)),
                'quat': Quaternion((qw, qx, qy, qz)),
            })
    return records[::step] if step > 1 else records


def interpolate_pose(records: list, ts: float):
    if not records:
        return None
    timestamps = [r['ts'] for r in records]
    if ts <= timestamps[0]:
        return records[0]['pos'].copy(), records[0]['quat'].copy()
    if ts >= timestamps[-1]:
        return records[-1]['pos'].copy(), records[-1]['quat'].copy()
    idx    = bisect.bisect_left(timestamps, ts)
    r0, r1 = records[idx-1], records[idx]
    factor = (ts - r0['ts']) / (r1['ts'] - r0['ts']) if r1['ts'] != r0['ts'] else 0.0
    return r0['pos'].lerp(r1['pos'], factor), r0['quat'].slerp(r1['quat'], factor)


# ════════════════════════════════════════════════════════════════
#  CAMERA MATRICES
# ════════════════════════════════════════════════════════════════

def imu_world_matrix(pos, quat, rx, ry, rz) -> Matrix:
    M = quat.to_matrix().to_4x4()
    M.translation = pos
    return (M
            @ Matrix.Rotation(math.radians(rx), 4, 'X')
            @ Matrix.Rotation(math.radians(ry), 4, 'Y')
            @ Matrix.Rotation(math.radians(rz), 4, 'Z'))


def cam_base_matrix(Mimu: Matrix, transform_matrix_flat: list) -> Matrix:
    T_ros     = _list_to_matrix4x4(transform_matrix_flat)
    T_bl      = _C_ROS2BL @ T_ros @ _C_ROS2BL.inverted()
    T_imu2cam = T_bl.inverted()
    return Mimu @ T_imu2cam @ CAMCONV


# ════════════════════════════════════════════════════════════════
#  CREATE BLENDER CAMERA
# ════════════════════════════════════════════════════════════════

def create_blender_camera(name, Mworld, M_base, calib_side: dict,
                          shift_x: float, shift_y: float,
                          focal_length_override=None, image_path=None):
    w  = calib_side.get('imagewidth',  1000)
    h  = calib_side.get('imageheight',  750)
    fx = calib_side.get('fx', 1135.0)

    camdata               = bpy.data.cameras.new(name=name)
    camdata.type          = 'PERSP'
    camdata.lens_unit     = 'MILLIMETERS'
    camdata.lens          = focal_length_override if focal_length_override else fx * 36.0 / w
    camdata.sensor_fit    = 'HORIZONTAL'
    camdata.sensor_width  = 36.0
    camdata.clip_start    = 0.01
    camdata.clip_end      = 1000.0
    camdata.shift_x       = shift_x
    camdata.shift_y       = shift_y
    camdata['calib_w']    = w
    camdata['calib_h']    = h

    if image_path and os.path.isfile(image_path):
        img                            = bpy.data.images.load(image_path, check_existing=True)
        bg                             = camdata.background_images.new()
        bg.image                       = img
        bg.alpha                       = 0.5
        bg.source                      = 'IMAGE'
        camdata.show_background_images = True

    obj                    = bpy.data.objects.new(name, camdata)
    obj.matrix_world       = Mworld
    obj['jmk6base_matrix'] = _base_matrix_to_list(M_base)
    return obj


# ════════════════════════════════════════════════════════════════
#  PROPERTIES
# ════════════════════════════════════════════════════════════════

class JMK6TrajProperties(PropertyGroup):

    trjfilepath:   StringProperty(
        name="Trajectory file",
        description="Path to the trajectory .txt file (TUM format: ts tx ty tz qx qy qz qw)",
        subtype='FILE_PATH', default="",
    )
    calibfilepath: StringProperty(
        name="Calib .json (optional)",
        description="Optional – overrides built-in Eagle JMK1002804 calibration",
        subtype='FILE_PATH', default="",
    )
    step: IntProperty(
        name="Every Nth point",
        description="Draw every Nth trajectory point (1 = all points)",
        default=10, min=1, max=1000,
    )

    # ── IMU orientation correction ────────────────────────────
    imurx: FloatProperty(
        name="Rx", description="IMU rotation offset around X axis [°]",
        default=90.0, min=-180.0, max=180.0, step=100, precision=1,
    )
    imury: FloatProperty(
        name="Ry", description="IMU rotation offset around Y axis [°]",
        default=0.0, min=-180.0, max=180.0, step=100, precision=1,
    )
    imurz: FloatProperty(
        name="Rz", description="IMU rotation offset around Z axis [°]",
        default=0.0, min=-180.0, max=180.0, step=100, precision=1,
    )

    # ── Image folders and visibility toggles ──────────────────
    folder_front:  StringProperty(name="Front folder",  subtype='DIR_PATH', default="")
    folder_back:   StringProperty(name="Back folder",   subtype='DIR_PATH', default="")
    folder_left:   StringProperty(name="Left folder",   subtype='DIR_PATH', default="")
    folder_right:  StringProperty(name="Right folder",  subtype='DIR_PATH', default="")

    draw_front:    BoolProperty(name="Front", default=True)
    draw_back:     BoolProperty(name="Back",  default=True)
    draw_left:     BoolProperty(name="Left",  default=True)
    draw_right:    BoolProperty(name="Right", default=True)

    imgstep: IntProperty(
        name="Every Nth image",
        description="Insert a camera for every Nth image in the folder",
        default=10, min=1, max=1000,
    )

    # ── Local camera corrections Roll/Pitch/Yaw ───────────────
    # Front: Rz=180  Rx=180  Ry=0
    cam_rz_front:  FloatProperty(name="Rz", description="Front camera – local roll  [°]",  default=180.0,  min=-180.0, max=180.0, step=100, precision=1, update=_make_update('front'))
    cam_rx_front:  FloatProperty(name="Rx", description="Front camera – local pitch [°]",  default=180.0,  min=-180.0, max=180.0, step=100, precision=1, update=_make_update('front'))
    cam_ry_front:  FloatProperty(name="Ry", description="Front camera – local yaw   [°]",  default=0.0,    min=-180.0, max=180.0, step=100, precision=1, update=_make_update('front'))
    # Back:  Rz=0  Rx=-180  Ry=0
    cam_rz_back:   FloatProperty(name="Rz", description="Back camera  – local roll  [°]",  default=0.0,    min=-180.0, max=180.0, step=100, precision=1, update=_make_update('back'))
    cam_rx_back:   FloatProperty(name="Rx", description="Back camera  – local pitch [°]",  default=-180.0, min=-180.0, max=180.0, step=100, precision=1, update=_make_update('back'))
    cam_ry_back:   FloatProperty(name="Ry", description="Back camera  – local yaw   [°]",  default=0.0,    min=-180.0, max=180.0, step=100, precision=1, update=_make_update('back'))
    # Left:  Rz=0  Rx=0  Ry=180
    cam_rz_left:   FloatProperty(name="Rz", description="Left camera  – local roll  [°]",  default=0.0,    min=-180.0, max=180.0, step=100, precision=1, update=_make_update('left'))
    cam_rx_left:   FloatProperty(name="Rx", description="Left camera  – local pitch [°]",  default=0.0,    min=-180.0, max=180.0, step=100, precision=1, update=_make_update('left'))
    cam_ry_left:   FloatProperty(name="Ry", description="Left camera  – local yaw   [°]",  default=180.0,  min=-180.0, max=180.0, step=100, precision=1, update=_make_update('left'))
    # Right: Rz=0  Rx=0  Ry=180
    cam_rz_right:  FloatProperty(name="Rz", description="Right camera – local roll  [°]",  default=0.0,    min=-180.0, max=180.0, step=100, precision=1, update=_make_update('right'))
    cam_rx_right:  FloatProperty(name="Rx", description="Right camera – local pitch [°]",  default=0.0,    min=-180.0, max=180.0, step=100, precision=1, update=_make_update('right'))
    cam_ry_right:  FloatProperty(name="Ry", description="Right camera – local yaw   [°]",  default=180.0,  min=-180.0, max=180.0, step=100, precision=1, update=_make_update('right'))

    # ── Working Shift X/Y (= sx0 * scale) ─────────────────────
    cam_sx_front:  FloatProperty(name="Shift X", description="Front camera – principal point offset X (Blender convention)", default= 1.5143, min=-5.0, max=5.0, step=1, precision=4, update=_make_update_shift('front'))
    cam_sy_front:  FloatProperty(name="Shift Y", description="Front camera – principal point offset Y (Blender convention)", default=-1.5171, min=-5.0, max=5.0, step=1, precision=4, update=_make_update_shift('front'))
    cam_sx_back:   FloatProperty(name="Shift X", description="Back camera  – principal point offset X (Blender convention)", default= 1.4053, min=-5.0, max=5.0, step=1, precision=4, update=_make_update_shift('back'))
    cam_sy_back:   FloatProperty(name="Shift Y", description="Back camera  – principal point offset Y (Blender convention)", default=-1.6602, min=-5.0, max=5.0, step=1, precision=4, update=_make_update_shift('back'))
    cam_sx_left:   FloatProperty(name="Shift X", description="Left camera  – principal point offset X (Blender convention)", default= 1.4799, min=-5.0, max=5.0, step=1, precision=4, update=_make_update_shift('left'))
    cam_sy_left:   FloatProperty(name="Shift Y", description="Left camera  – principal point offset Y (Blender convention)", default=-1.5309, min=-5.0, max=5.0, step=1, precision=4, update=_make_update_shift('left'))
    cam_sx_right:  FloatProperty(name="Shift X", description="Right camera – principal point offset X (Blender convention)", default= 1.6506, min=-5.0, max=5.0, step=1, precision=4, update=_make_update_shift('right'))
    cam_sy_right:  FloatProperty(name="Shift Y", description="Right camera – principal point offset Y (Blender convention)", default=-1.5282, min=-5.0, max=5.0, step=1, precision=4, update=_make_update_shift('right'))

    # ── Calibration-based Shift X/Y (source for scaling) ──────
    cam_sx0_front: FloatProperty(default= 1.5143)
    cam_sy0_front: FloatProperty(default=-1.5171)
    cam_sx0_back:  FloatProperty(default= 1.4053)
    cam_sy0_back:  FloatProperty(default=-1.6602)
    cam_sx0_left:  FloatProperty(default= 1.4799)
    cam_sy0_left:  FloatProperty(default=-1.5309)
    cam_sx0_right: FloatProperty(default= 1.6506)
    cam_sy0_right: FloatProperty(default=-1.5282)

    # ── Global Shift X/Y scale slider ─────────────────────────
    cam_shift_scale: FloatProperty(
        name="Shift X/Y Scale",
        description=(
            "Proportional scaling of principal point offset\n"
            "for all 4 cameras simultaneously.\n"
            "0.00 = no offset  |  1.00 = full calibration value"
        ),
        default=0.10, min=0.00, max=1.00,
        step=1, precision=2,
        update=_update_shift_scale,
    )

    # ── Camera display parameters ──────────────────────────────
    cam_display_size: FloatProperty(
        name="Camera size [m]",
        description="Display size of camera objects in the viewport",
        default=0.05, min=0.005, max=1.0,
    )
    load_images: BoolProperty(
        name="Load images as background",
        description="Load matching images as camera background images",
        default=False,
    )
    cam_focal_length: FloatProperty(
        name="Focal Length [mm]",
        description="Camera focal length – updates all Eagle cameras live",
        default=10.2, min=1.0, max=300.0, step=10, precision=2,
        update=_update_focal_length,
    )
    cam_bg_alpha: FloatProperty(
        name="BG alpha",
        description="Transparency of background images in the viewport",
        default=0.5, min=0.0, max=1.0,
    )

    # ── COLMAP export ──────────────────────────────────────────
    export_dir:    StringProperty(
        name="Export directory",
        description="Output directory for COLMAP images.txt and cameras.txt",
        subtype='DIR_PATH', default="",
    )
    export_images: BoolProperty(
        name="Copy images",
        description="Copy source images to images/ subdirectory",
        default=False,
    )


# ════════════════════════════════════════════════════════════════
#  OPERATOR – DRAW PATH
# ════════════════════════════════════════════════════════════════

class JMK6_OT_DrawPath(Operator):
    bl_idname      = "jmk6.drawpath"
    bl_label       = "Draw trajectory path"
    bl_description = "Load trajectory file and draw the scanner path in the viewport"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.jmk6traj
        if not os.path.isfile(props.trjfilepath):
            self.report({'ERROR'}, f"File not found: {props.trjfilepath}")
            return {'CANCELLED'}
        records = load_trajectory(props.trjfilepath, step=props.step)
        if not records:
            self.report({'ERROR'}, "Trajectory file is empty or invalid.")
            return {'CANCELLED'}

        for o in list(bpy.data.objects):
            if o.name == "JMK6Path":
                bpy.data.objects.remove(o, do_unlink=True)
        for m in list(bpy.data.meshes):
            if m.name == "JMK6PathMesh":
                bpy.data.meshes.remove(m)

        verts = [(r['pos'].x, r['pos'].y, r['pos'].z) for r in records]
        edges = [(i, i+1) for i in range(len(verts)-1)]
        mesh  = bpy.data.meshes.new("JMK6PathMesh")
        mesh.from_pydata(verts, edges, [])
        mesh.update()
        obj       = bpy.data.objects.new("JMK6Path", mesh)
        obj.color = (0.0, 0.8, 1.0, 1.0)
        get_or_create_collection("JMK6Trajectory").objects.link(obj)

        full = load_trajectory(props.trjfilepath, step=1)
        context.scene['jmk6trjdata'] = [
            [r['ts'], r['pos'].x, r['pos'].y, r['pos'].z,
             r['quat'].x, r['quat'].y, r['quat'].z, r['quat'].w]
            for r in full
        ]
        self.report({'INFO'},
            f"Loaded {len(records)} path points / {len(full)} for interpolation.")
        return {'FINISHED'}


# ════════════════════════════════════════════════════════════════
#  OPERATOR – INSERT CAMERAS
# ════════════════════════════════════════════════════════════════

class JMK6_OT_InsertCameras(Operator):
    bl_idname      = "jmk6.insertcameras"
    bl_label       = "Insert cameras from image timestamps"
    bl_description = "Create camera objects at interpolated trajectory poses matching image timestamps"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.jmk6traj

        raw = context.scene.get('jmk6trjdata')
        if raw:
            records = [
                {'ts':   row[0],
                 'pos':  Vector(row[1:4]),
                 'quat': Quaternion((row[7], row[4], row[5], row[6]))}
                for row in raw
            ]
        elif os.path.isfile(props.trjfilepath):
            records = load_trajectory(props.trjfilepath, step=1)
        else:
            self.report({'ERROR'}, "No trajectory data – click 'Draw trajectory path' first.")
            return {'CANCELLED'}
        if not records:
            self.report({'ERROR'}, "No trajectory points available.")
            return {'CANCELLED'}

        if props.calibfilepath and os.path.isfile(props.calibfilepath):
            try:
                calib = load_calib(props.calibfilepath)
            except Exception as e:
                self.report({'WARNING'}, f"calib.json error: {e}. Using built-in calibration.")
                calib = DEFAULT_CALIB
        else:
            calib = DEFAULT_CALIB

        scale = props.cam_shift_scale
        for side in SIDES:
            cd = calib.get(side, DEFAULT_CALIB[side])
            w  = cd.get('imagewidth',  1000)
            h  = cd.get('imageheight',  750)
            sx0, sy0 = calib_to_shift(cd.get('cx', w/2.0), cd.get('cy', h/2.0), w, h)
            setattr(props, f"cam_sx0_{side}", sx0)
            setattr(props, f"cam_sy0_{side}", sy0)
            setattr(props, f"cam_sx_{side}",  sx0 * scale)
            setattr(props, f"cam_sy_{side}",  sy0 * scale)

        tasks = []
        for side in SIDES:
            folder = getattr(props, f"folder_{side}")
            draw   = getattr(props, f"draw_{side}")
            if draw and folder:
                imgs = collect_image_timestamps(folder)
                tasks.extend((side, ts, fp) for ts, fp in imgs[::props.imgstep])

        if not tasks:
            self.report({'WARNING'}, "No images found – check the folder paths.")
            return {'CANCELLED'}

        collections = {}
        prefixes    = [cfg['prefix'] for cfg in CAM_CFG.values()]
        for side in SIDES:
            col = get_or_create_collection(f"JMK6CAM{side.capitalize()}")
            clear_collection(col)
            collections[side] = col
        for cam in list(bpy.data.cameras):
            if any(cam.name.startswith(p) for p in prefixes):
                bpy.data.cameras.remove(cam)

        inserted = skipped = 0

        for side, ts, filepath in tasks:
            result = interpolate_pose(records, ts)
            if result is None:
                skipped += 1
                continue
            pos, quat = result

            Mimu    = imu_world_matrix(pos, quat,
                                       props.imurx, props.imury, props.imurz)
            cd      = calib.get(side, DEFAULT_CALIB[side])
            tm_flat = cd.get('transform_matrix', DEFAULT_CALIB[side]['transform_matrix'])
            M_base  = cam_base_matrix(Mimu, tm_flat)

            rz = getattr(props, f"cam_rz_{side}")
            rx = getattr(props, f"cam_rx_{side}")
            ry = getattr(props, f"cam_ry_{side}")
            Mfinal = _apply_local_corrections(M_base, rz, rx, ry)

            sx = getattr(props, f"cam_sx_{side}")
            sy = getattr(props, f"cam_sy_{side}")

            cfg     = CAM_CFG[side]
            camname = f"{cfg['prefix']}{ts:.3f}"
            imgpath = filepath if props.load_images else None

            camobj = create_blender_camera(
                camname, Mfinal, M_base, cd,
                shift_x=sx, shift_y=sy,
                focal_length_override=props.cam_focal_length,
                image_path=imgpath,
            )
            camobj.data.display_size = props.cam_display_size
            camobj.color             = cfg['color']
            camobj['jmk6image']      = os.path.basename(filepath)
            camobj['jmk6timestamp']  = ts
            camobj['jmk6side']       = side
            camobj['jmk6src_path']   = filepath

            for c in list(camobj.users_collection):
                c.objects.unlink(camobj)
            collections[side].objects.link(camobj)
            inserted += 1

        sc = context.scene
        sc.unit_settings.system       = 'METRIC'
        sc.unit_settings.scale_length = 1.0
        sc.unit_settings.length_unit  = 'METERS'

        self.report({'INFO'},
            f"Inserted {inserted} Eagle cameras, skipped {skipped} (out of range).")
        return {'FINISHED'}


# ════════════════════════════════════════════════════════════════
#  OPERATOR – EXPORT COLMAP
# ════════════════════════════════════════════════════════════════

class JMK6_OT_ExportCOLMAP(Operator):
    bl_idname      = "jmk6.export_colmap"
    bl_label       = "Export to COLMAP"
    bl_description = "Write images.txt and cameras.txt for COLMAP SfM reconstruction"
    bl_options     = {'REGISTER'}

    def _blender_to_colmap(self, obj):
        M     = obj.matrix_world
        C_CV  = Matrix(((1, 0, 0), (0, -1, 0), (0, 0, -1)))
        R_w2c = (M.to_3x3() @ C_CV).transposed()
        t     = R_w2c @ (-M.translation)
        q     = R_w2c.to_quaternion()
        return q, t

    def execute(self, context):
        props   = context.scene.jmk6traj
        out_dir = bpy.path.abspath(props.export_dir)
        if not out_dir:
            self.report({'ERROR'}, "Please specify an export directory.")
            return {'CANCELLED'}
        os.makedirs(out_dir, exist_ok=True)

        cams_by_side = {}
        all_cams     = []
        for side, cfg in CAM_CFG.items():
            lst = sorted(
                [o for o in bpy.data.objects
                 if o.type == 'CAMERA' and o.name.startswith(cfg['prefix'])],
                key=lambda o: o.get('jmk6timestamp', 0.0),
            )
            cams_by_side[side] = lst
            all_cams.extend(lst)

        if not all_cams:
            self.report({'ERROR'}, "No Eagle cameras found in the scene.")
            return {'CANCELLED'}

        img_lines = [
            "# Image list with two lines of data per image:\n",
            "#   IMAGE_ID, QW, QX, QY, QZ, TX, TY, TZ, CAMERA_ID, NAME\n",
        ]
        for img_id, obj in enumerate(all_cams, start=1):
            q, t   = self._blender_to_colmap(obj)
            side   = obj.get('jmk6side', 'front')
            cam_id = CAM_CFG[side]['cam_id']
            name   = obj.get('jmk6image', f"frame_{img_id:04d}.png")
            img_lines.append(
                f"{img_id} "
                f"{q.w:.6f} {q.x:.6f} {q.y:.6f} {q.z:.6f} "
                f"{t.x:.6f} {t.y:.6f} {t.z:.6f} "
                f"{cam_id} {name}\n"
            )
            img_lines.append("0.0 0.0 -1\n")

        with open(os.path.join(out_dir, "images.txt"), 'w') as f:
            f.writelines(img_lines)

        cam_lines = [
            "# Camera list with one line of data per camera:\n",
            "#   CAMERA_ID, MODEL, WIDTH, HEIGHT, PARAMS[]\n",
        ]
        for side in SIDES:
            cfg  = CAM_CFG[side]
            cd_d = DEFAULT_CALIB[side]
            w, h = cd_d['imagewidth'], cd_d['imageheight']
            lst  = cams_by_side[side]
            if lst:
                cd  = lst[0].data
                sw  = cd.sensor_width if cd.sensor_width > 0 else 36.0
                fx  = cd.lens * w / sw
                fy  = cd.lens * h / sw
                cx  = (cd.shift_x + 0.5) * w
                cy  = (0.5 - cd.shift_y) * h
            else:
                fx  = cd_d['fx']
                fy  = cd_d['fy']
                cx  = cd_d['cx']
                cy  = cd_d['cy']
            cam_lines.append(
                f"{cfg['cam_id']} PINHOLE {w} {h} "
                f"{fx:.3f} {fy:.3f} {cx:.3f} {cy:.3f}\n"
            )

        with open(os.path.join(out_dir, "cameras.txt"), 'w') as f:
            f.writelines(cam_lines)

        copied = 0
        if props.export_images:
            img_dir = os.path.join(out_dir, "images")
            os.makedirs(img_dir, exist_ok=True)
            for obj in all_cams:
                src  = obj.get('jmk6src_path', '')
                name = obj.get('jmk6image', '')
                if src and os.path.isfile(src) and name:
                    dst = os.path.join(img_dir, name)
                    if not os.path.exists(dst):
                        shutil.copy2(src, dst)
                    copied += 1

        msg = (f"Exported: {len(all_cams)} cameras → {out_dir}"
               + (f" | copied {copied} images" if props.export_images else ""))
        self.report({'INFO'}, msg)
        return {'FINISHED'}


# ════════════════════════════════════════════════════════════════
#  CAMERA CONTROL OPERATORS
# ════════════════════════════════════════════════════════════════

class JMK6_OT_MatchResolution(Operator):
    bl_idname      = "jmk6.matchresolution"
    bl_label       = "Match scene resolution to image"
    bl_description = "Set render resolution to match the active Eagle camera's background image or calibration data"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if obj is None or obj.type != 'CAMERA':
            self.report({'ERROR'}, "Select an Eagle camera as the active object.")
            return {'CANCELLED'}
        cd   = obj.data
        w, h = None, None
        for bg in cd.background_images:
            if bg.image and bg.image.size[0] > 0:
                w, h = int(bg.image.size[0]), int(bg.image.size[1])
                break
        if w is None:
            w = int(cd.get('calib_w', 0))
            h = int(cd.get('calib_h', 0))
        if not w or not h:
            self.report({'WARNING'}, "No background image or calibration data found.")
            return {'CANCELLED'}
        sc = context.scene
        sc.render.resolution_x          = w
        sc.render.resolution_y          = h
        sc.render.resolution_percentage = 100
        cd.sensor_fit = 'HORIZONTAL' if w >= h else 'VERTICAL'
        self.report({'INFO'}, f"Scene resolution set to {w} × {h} px")
        return {'FINISHED'}


class JMK6_OT_ViewFromCamera(Operator):
    bl_idname      = "jmk6.viewfromcamera"
    bl_label       = "View from active camera"
    bl_description = "Set the active Eagle camera as the scene camera and switch viewport to camera view"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        obj = context.active_object
        if obj is None or obj.type != 'CAMERA':
            self.report({'ERROR'}, "Select an Eagle camera as the active object.")
            return {'CANCELLED'}
        context.scene.camera = obj
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        space.region_3d.view_perspective = 'CAMERA'
                break
        self.report({'INFO'}, f"Viewing from: {obj.name}")
        return {'FINISHED'}


class JMK6_OT_SetBgAlpha(Operator):
    bl_idname      = "jmk6.setbgalpha"
    bl_label       = "Apply background alpha"
    bl_description = "Apply the BG alpha value to all Eagle cameras with background images"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        alpha    = context.scene.jmk6traj.cam_bg_alpha
        prefixes = tuple(cfg['prefix'] for cfg in CAM_CFG.values())
        updated  = 0
        for obj in bpy.data.objects:
            if obj.type == 'CAMERA' and obj.name.startswith(prefixes):
                for bg in obj.data.background_images:
                    bg.alpha = alpha
                    updated += 1
        if updated == 0:
            self.report({'WARNING'}, "No cameras with background images found.")
            return {'CANCELLED'}
        self.report({'INFO'}, f"Set alpha={alpha:.2f} for {updated} background image(s).")
        return {'FINISHED'}


class JMK6_OT_CreateAnimation(Operator):
    bl_idname      = "jmk6.createanimation"
    bl_label       = "Generate animation from cameras"
    bl_description = "Create timeline markers for every Eagle camera and link them to frames"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        sc       = context.scene
        all_cams = []
        counts   = {}
        for side in SIDES:
            cfg = CAM_CFG[side]
            lst = sorted(
                [o for o in bpy.data.objects
                 if o.type == 'CAMERA' and o.name.startswith(cfg['prefix'])],
                key=lambda o: o.get('jmk6timestamp', 0.0),
            )
            counts[side] = len(lst)
            all_cams.extend(lst)

        if not all_cams:
            self.report({'ERROR'}, "No Eagle cameras found in the scene.")
            return {'CANCELLED'}

        for m in [m for m in sc.timeline_markers if m.name.startswith("JMK6")]:
            sc.timeline_markers.remove(m)
        sc.frame_start = 1
        sc.frame_end   = len(all_cams)

        for frame_idx, camobj in enumerate(all_cams, start=1):
            side   = camobj.get('jmk6side', '?').upper()[:1]
            marker = sc.timeline_markers.new(f"JMK6{side}{frame_idx:04d}", frame=frame_idx)
            marker.camera = camobj

        sc.camera = all_cams[0]
        report_str = " | ".join(f"{s}: {counts[s]}" for s in SIDES)
        self.report({'INFO'}, f"Animation: {len(all_cams)} frames  [{report_str}]")
        return {'FINISHED'}


class JMK6_OT_ClearAll(Operator):
    bl_idname      = "jmk6.clearall"
    bl_label       = "Clear JMK6 scene"
    bl_description = "Remove all Eagle cameras, trajectory path, collections and timeline markers from the scene"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        prefixes = tuple(cfg['prefix'] for cfg in CAM_CFG.values())
        removed  = 0
        for obj in list(bpy.data.objects):
            if obj.name.startswith(("JMK6",) + prefixes):
                bpy.data.objects.remove(obj, do_unlink=True)
                removed += 1
        for mesh in list(bpy.data.meshes):
            if mesh.name.startswith("JMK6"):
                bpy.data.meshes.remove(mesh)
        for cam in list(bpy.data.cameras):
            if cam.name.startswith(prefixes):
                bpy.data.cameras.remove(cam)
        for col in list(bpy.data.collections):
            if col.name.startswith("JMK6"):
                bpy.data.collections.remove(col)
        for m in [m for m in context.scene.timeline_markers if m.name.startswith("JMK6")]:
            context.scene.timeline_markers.remove(m)
        if 'jmk6trjdata' in context.scene:
            del context.scene['jmk6trjdata']
        self.report({'INFO'}, f"Removed {removed} JMK6/Eagle objects.")
        return {'FINISHED'}


# ════════════════════════════════════════════════════════════════
#  PANEL
# ════════════════════════════════════════════════════════════════

_SIDE_LABELS = {
    'front': "Front  (green)",
    'back':  "Back   (red)",
    'left':  "Left   (blue)",
    'right': "Right  (orange)",
}


class JMK6_PT_MainPanel(Panel):
    bl_label       = "JMK6 Eagle Trajectory"
    bl_idname      = "JMK6_PT_main"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "JMK6 Traj"

    def draw(self, context):
        layout = self.layout
        props  = context.scene.jmk6traj

        # 1. Input files
        box = layout.box()
        box.label(text="Input files", icon='FILE_FOLDER')
        box.prop(props, "trjfilepath",   text="Trajectory .txt")
        box.prop(props, "calibfilepath", text="Calib .json – optional")

        # 2. Trajectory path
        box2 = layout.box()
        box2.label(text="Trajectory path", icon='CURVE_PATH')
        box2.prop(props, "step", text="Every Nth point")
        box2.operator("jmk6.drawpath", icon='PLAY')

        # 3. IMU orientation correction
        box3 = layout.box()
        box3.label(text="IMU orientation correction", icon='ORIENTATION_GIMBAL')
        box3.label(text="R_bl = R_quat · Rx · Ry · Rz", icon='INFO')
        row = box3.row(align=True)
        row.prop(props, "imurx")
        row.prop(props, "imury")
        row.prop(props, "imurz")

        # 4. Cameras
        box4 = layout.box()
        box4.label(text="Eagle cameras – 4×  (front/back/left/right)", icon='CAMERA_DATA')

        row = box4.row()
        for side in SIDES:
            row.prop(props, f"draw_{side}")
        for side in SIDES:
            box4.prop(props, f"folder_{side}", text=f"{side.capitalize()} folder")
        box4.prop(props, "imgstep", text="Every Nth image")

        # Local corrections Rz/Rx/Ry + Shift X/Y per camera
        box4.separator(factor=0.5)
        box4.label(text="Local camera corrections (live):", icon='CON_ROTLIKE')

        for side in SIDES:
            sub = box4.box()
            sub.scale_y = 0.85
            sub.label(text=_SIDE_LABELS[side])
            row_r = sub.row(align=True)
            row_r.prop(props, f"cam_rz_{side}", text="Rz")
            row_r.prop(props, f"cam_rx_{side}", text="Rx")
            row_r.prop(props, f"cam_ry_{side}", text="Ry")
            sub.separator(factor=0.3)
            row_s = sub.row(align=True)
            row_s.prop(props, f"cam_sx_{side}", text="Shift X")
            row_s.prop(props, f"cam_sy_{side}", text="Shift Y")

        # Global Shift X/Y scale slider
        box4.separator(factor=0.5)
        box_sc = box4.box()
        box_sc.label(text="Global Shift X/Y scale (all cameras):",
                     icon='DRIVER_TRANSFORM')
        box_sc.prop(props, "cam_shift_scale", slider=True,
                    text="Scale  0.00 = none  |  1.00 = full calibration")
        col_info = box_sc.column(align=True)
        col_info.scale_y = 0.7
        scale = props.cam_shift_scale
        for side in SIDES:
            sx0 = getattr(props, f"cam_sx0_{side}")
            sy0 = getattr(props, f"cam_sy0_{side}")
            col_info.label(
                text=f"  {side:<5}  sx={sx0*scale:+.4f}  sy={sy0*scale:+.4f}",
                icon='BLANK1',
            )

        box4.separator(factor=0.5)
        box4.prop(props, "cam_display_size", text="Camera size [m]")
        box4.prop(props, "load_images",      text="Load images as background")
        box4.prop(props, "cam_focal_length", text="Focal Length [mm]")
        box4.operator("jmk6.insertcameras", icon='OBJECT_ORIGIN')

        # 5. Render resolution
        box5 = layout.box()
        box5.label(text="Render resolution", icon='SCENE')
        sc = context.scene
        box5.label(text=f"Scene: {sc.render.resolution_x} × {sc.render.resolution_y} px",
                   icon='INFO')
        act = context.active_object
        if act and act.type == 'CAMERA':
            cd = act.data
            cw = int(cd.get('calib_w', 0))
            ch = int(cd.get('calib_h', 0))
            if cw and ch:
                box5.label(text=f"Calibration: {cw} × {ch} px", icon='CAMERA_DATA')
            for bg in cd.background_images:
                if bg.image and bg.image.size[0] > 0:
                    iw, ih = int(bg.image.size[0]), int(bg.image.size[1])
                    box5.label(text=f"Background image: {iw} × {ih} px", icon='IMAGE_DATA')
                    break
            box5.label(
                text=f"shift_x={cd.shift_x:.4f}  shift_y={cd.shift_y:.4f}",
                icon='DRIVER_TRANSFORM',
            )
        box5.operator("jmk6.matchresolution", icon='FULLSCREEN_ENTER')

        # 5b. Camera control
        box5b = layout.box()
        box5b.label(text="Camera control", icon='TOOL_SETTINGS')
        col_fl = box5b.column(align=True)
        col_fl.prop(props, "cam_focal_length", text="Focal Length [mm]")
        sub_fl = col_fl.row()
        sub_fl.scale_y = 0.65
        sub_fl.label(text="↑ updates all cameras live", icon='INFO')
        box5b.operator("jmk6.viewfromcamera", icon='OUTLINER_OB_CAMERA')
        row_al = box5b.row(align=True)
        row_al.prop(props, "cam_bg_alpha", text="BG alpha", slider=True)
        row_al.operator("jmk6.setbgalpha", text="", icon='IMAGE_ALPHA')
        box5b.separator()
        box5b.operator("jmk6.createanimation", icon='RENDER_ANIMATION')

        # 6. COLMAP export
        box6 = layout.box()
        box6.label(text="COLMAP export", icon='EXPORT')
        box6.prop(props, "export_dir",    text="Directory")
        box6.prop(props, "export_images", text="Copy images to images/")
        sub6 = box6.column(align=True)
        sub6.scale_y = 0.8
        sub6.label(text="Generates: images.txt  cameras.txt (4 entries)", icon='INFO')
        sub6.label(text="front=1  back=2  left=3  right=4")
        box6.operator("jmk6.export_colmap", icon='EXPORT')

        # 7. Clean up
        layout.separator()
        layout.operator("jmk6.clearall", icon='TRASH')


# ════════════════════════════════════════════════════════════════
#  REGISTRATION
# ════════════════════════════════════════════════════════════════

_classes = (
    JMK6TrajProperties,
    JMK6_OT_DrawPath,
    JMK6_OT_InsertCameras,
    JMK6_OT_ExportCOLMAP,
    JMK6_OT_MatchResolution,
    JMK6_OT_ViewFromCamera,
    JMK6_OT_SetBgAlpha,
    JMK6_OT_CreateAnimation,
    JMK6_OT_ClearAll,
    JMK6_PT_MainPanel,
)

def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.jmk6traj = PointerProperty(type=JMK6TrajProperties)

def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.jmk6traj

if __name__ == "__main__":
    register()