# ##### BEGIN GPL LICENSE BLOCK #####
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
# ##### END GPL LICENSE BLOCK #####

bl_info = {
    "name": "COLMAP Point Cloud Tools",
    "author": "rafal.karnicki@pwr.edu.pl with Perplexity AI",
    "version": (2, 4, 0),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > LiDAR",
    "description": "Import, visualize and export COLMAP/PLY/XYZ/LAS/LAZ point clouds",
    "warning": "",
    "category": "Import-Export",
}

import os
import io
import struct
import subprocess
import sys
import bpy
import numpy as np
from bpy.props import (
    StringProperty,
    IntProperty,
    FloatProperty,
    BoolProperty,
)


# ============================================================================
# AUTO-INSTALACJA laspy
# ============================================================================

def ensure_laspy():
    try:
        import laspy
        return True
    except ImportError:
        python_exec = sys.executable
        try:
            subprocess.check_call(
                [python_exec, "-m", "pip", "install", "laspy[lazrs]"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return True
        except Exception as e:
            print(f"[PointCloud Tools] Nie udalo sie zainstalowac laspy: {e}")
            return False


# ============================================================================
# DETEKCJA FORMATU
# ============================================================================

def detect_format(filepath):
    ext = os.path.splitext(filepath)[1].lower()
    if ext == ".ply":
        return "ply"
    if ext == ".xyz":
        return "xyz"
    if ext in (".las", ".laz"):
        return "las"
    return "colmap"


# ============================================================================
# FORMAT XYZ
# ============================================================================

def count_points_xyz(filepath):
    count = 0
    with open(filepath, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if len(line.split()) >= 3:
                count += 1
    return count


def load_xyz(filepath, interval, ts_idx, te_idx, use_radius, radius_sq):
    total = count_points_xyz(filepath)
    if total == 0:
        return None, None, 0, 0

    max_pts   = max(1, (te_idx - ts_idx + interval - 1) // interval)
    positions = np.empty((max_pts, 3), dtype=np.float32)
    colors    = np.empty((max_pts, 4), dtype=np.float32)
    count     = 0
    data_idx  = 0

    with open(filepath, "r") as f:
        for raw_line in f:
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if data_idx < ts_idx or data_idx >= te_idx:
                data_idx += 1
                continue
            if (data_idx - ts_idx) % interval != 0:
                data_idx += 1
                continue
            parts = line.split()
            if len(parts) < 3:
                data_idx += 1
                continue
            try:
                x = float(parts[0])
                y = float(parts[1])
                z = float(parts[2])
                if use_radius and (x * x + y * y + z * z) > radius_sq:
                    data_idx += 1
                    continue
                if len(parts) >= 6:
                    r = int(parts[3]) / 255.0
                    g = int(parts[4]) / 255.0
                    b = int(parts[5]) / 255.0
                else:
                    r = g = b = 128 / 255.0
                positions[count] = (x, y, z)
                colors[count]    = (r, g, b, 1.0)
                count += 1
            except (ValueError, IndexError):
                pass
            data_idx += 1

    return positions[:count], colors[:count], total, count


# ============================================================================
# FORMAT PLY
# ============================================================================

def _parse_ply_header(f):
    header_lines = []
    while True:
        line = f.readline().decode("ascii", errors="replace").strip()
        header_lines.append(line)
        if line == "end_header":
            break

    fmt       = "ascii"
    n_verts   = 0
    props     = []
    in_vertex = False

    ply_type_map = {
        "float": ("f", 4), "float32": ("f", 4),
        "double": ("d", 8), "float64": ("d", 8),
        "int": ("i", 4), "int32": ("i", 4),
        "uint": ("I", 4), "uint32": ("I", 4),
        "short": ("h", 2), "int16": ("h", 2),
        "ushort": ("H", 2), "uint16": ("H", 2),
        "char": ("b", 1), "int8": ("b", 1),
        "uchar": ("B", 1), "uint8": ("B", 1),
    }

    for line in header_lines:
        tokens = line.split()
        if not tokens:
            continue
        if tokens[0] == "format":
            fmt = tokens[1]
        elif tokens[0] == "element":
            in_vertex = tokens[1] == "vertex"
            if in_vertex:
                n_verts = int(tokens[2])
        elif tokens[0] == "property" and in_vertex:
            if tokens[1] == "list":
                props.append((tokens[3], None, 0))
            else:
                info = ply_type_map.get(tokens[1], ("f", 4))
                props.append((tokens[2], info[0], info[1]))

    return {
        "format": fmt,
        "n_vertices": n_verts,
        "props": props,
        "header_end_offset": f.tell(),
    }


def load_ply(filepath, interval, ts_idx, te_idx, use_radius, radius_sq):
    with open(filepath, "rb") as f:
        magic = f.read(4)
        if magic != b"ply\n" and magic[:3] != b"ply":
            raise ValueError("Plik nie jest poprawnym PLY")
        f.seek(0)
        hdr = _parse_ply_header(f)

    data_offset = hdr["header_end_offset"]
    fmt         = hdr["format"]
    n_verts     = hdr["n_vertices"]
    props       = hdr["props"]

    if n_verts == 0:
        return None, None, 0, 0

    prop_names = [p[0] for p in props]
    ix = prop_names.index("x") if "x" in prop_names else -1
    iy = prop_names.index("y") if "y" in prop_names else -1
    iz = prop_names.index("z") if "z" in prop_names else -1
    ir = next((i for i, n in enumerate(prop_names) if n in ("red",   "r")), -1)
    ig = next((i for i, n in enumerate(prop_names) if n in ("green", "g")), -1)
    ib = next((i for i, n in enumerate(prop_names) if n in ("blue",  "b")), -1)

    if ix < 0 or iy < 0 or iz < 0:
        raise ValueError("Plik PLY nie zawiera wlasciwosci x/y/z")

    def is_uchar(idx):
        return idx >= 0 and props[idx][1] == "B"

    max_pts   = max(1, (te_idx - ts_idx + interval - 1) // interval)
    positions = np.empty((max_pts, 3), dtype=np.float32)
    colors    = np.empty((max_pts, 4), dtype=np.float32)
    count     = 0

    if fmt == "ascii":
        with open(filepath, "r", errors="replace") as f:
            for line in f:
                if line.strip() == "end_header":
                    break
            data_idx = 0
            for raw_line in f:
                line = raw_line.strip()
                if not line:
                    continue
                if data_idx < ts_idx or data_idx >= te_idx:
                    data_idx += 1
                    continue
                if (data_idx - ts_idx) % interval != 0:
                    data_idx += 1
                    continue
                parts = line.split()
                try:
                    x = float(parts[ix])
                    y = float(parts[iy])
                    z = float(parts[iz])
                    if use_radius and (x * x + y * y + z * z) > radius_sq:
                        data_idx += 1
                        continue
                    if ir >= 0 and ig >= 0 and ib >= 0:
                        rv = float(parts[ir])
                        gv = float(parts[ig])
                        bv = float(parts[ib])
                        if is_uchar(ir):
                            rv /= 255.0
                            gv /= 255.0
                            bv /= 255.0
                    else:
                        rv = gv = bv = 0.5
                    positions[count] = (x, y, z)
                    colors[count]    = (rv, gv, bv, 1.0)
                    count += 1
                except (ValueError, IndexError):
                    pass
                data_idx += 1
    else:
        endian     = "<" if fmt == "binary_little_endian" else ">"
        struct_fmt = endian
        byte_off   = 0
        for pname, pfmt, psize in props:
            if pfmt is None:
                continue
            struct_fmt += pfmt
            byte_off   += psize
        row_size  = struct.calcsize(struct_fmt)
        val_names = [p[0] for p in props if p[1] is not None]

        with open(filepath, "rb") as f:
            f.seek(data_offset)
            data_idx = 0
            for vi in range(n_verts):
                raw = f.read(row_size)
                if len(raw) < row_size:
                    break
                if data_idx < ts_idx or data_idx >= te_idx:
                    data_idx += 1
                    continue
                if (data_idx - ts_idx) % interval != 0:
                    data_idx += 1
                    continue
                vals = struct.unpack(struct_fmt, raw)
                vd   = {n: vals[i] for i, n in enumerate(val_names)}
                try:
                    x = vd["x"]
                    y = vd["y"]
                    z = vd["z"]
                    if use_radius and (x * x + y * y + z * z) > radius_sq:
                        data_idx += 1
                        continue

                    def _gc(names, vd=vd, prop_names=prop_names, props=props):
                        for n in names:
                            if n in vd:
                                v = float(vd[n])
                                idx = prop_names.index(n)
                                return v / 255.0 if props[idx][1] == "B" else v
                        return 0.5

                    rv = _gc(("red",   "r"))
                    gv = _gc(("green", "g"))
                    bv = _gc(("blue",  "b"))
                    positions[count] = (x, y, z)
                    colors[count]    = (rv, gv, bv, 1.0)
                    count += 1
                except KeyError:
                    pass
                data_idx += 1

    return positions[:count], colors[:count], n_verts, count


# ============================================================================
# FORMAT LAS / LAZ
# Priorytet kolorow:
#   1. RGB (point format 2,3,5,7,8) - uint16/65535
#   2. Intensity - uint16/65535 jako skala szarosci R=G=B
#   3. Brak obu  - staly szary 128/255
# ============================================================================

def load_las(filepath, interval, ts_idx, te_idx, use_radius, radius_sq):
    try:
        import laspy
    except ImportError:
        raise ImportError(
            "Biblioteka laspy nie jest zainstalowana. "
            "Uruchom ponownie Blender po instalacji."
        )

    las   = laspy.read(filepath)
    total = len(las.points)
    if total == 0:
        return None, None, 0, 0

    dim_names     = [d.name for d in las.point_format.dimensions]
    has_rgb       = all(c in dim_names for c in ("red", "green", "blue"))
    has_intensity = "intensity" in dim_names

    xs = np.asarray(las.x, dtype=np.float32)
    ys = np.asarray(las.y, dtype=np.float32)
    zs = np.asarray(las.z, dtype=np.float32)

    sl = slice(ts_idx, te_idx)
    xs = xs[sl]
    ys = ys[sl]
    zs = zs[sl]

    if has_rgb:
        rs = np.asarray(las.red  [sl], dtype=np.float32) / 65535.0
        gs = np.asarray(las.green[sl], dtype=np.float32) / 65535.0
        bs = np.asarray(las.blue [sl], dtype=np.float32) / 65535.0
    elif has_intensity:
        grey = np.asarray(las.intensity[sl], dtype=np.float32) / 65535.0
        rs = gs = bs = grey
    else:
        grey = np.full(len(xs), 128 / 255.0, dtype=np.float32)
        rs = gs = bs = grey

    xs = xs[::interval]
    ys = ys[::interval]
    zs = zs[::interval]
    rs = rs[::interval]
    gs = gs[::interval]
    bs = bs[::interval]

    if use_radius:
        mask = (xs ** 2 + ys ** 2 + zs ** 2) <= radius_sq
        xs = xs[mask]; ys = ys[mask]; zs = zs[mask]
        rs = rs[mask]; gs = gs[mask]; bs = bs[mask]

    n = len(xs)
    if n == 0:
        return None, None, total, 0

    positions = np.column_stack((xs, ys, zs)).astype(np.float32)
    ones      = np.ones(n, dtype=np.float32)
    colors    = np.column_stack((rs, gs, bs, ones)).astype(np.float32)

    return positions, colors, total, n


# ============================================================================
# FORMAT COLMAP
# ============================================================================

def _count_colmap(filepath):
    count = 0
    with open(filepath, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if len(line.split()) >= 8:
                count += 1
    return count


def _count_ply_header(filepath):
    with open(filepath, "rb") as f:
        for _ in range(200):
            line = f.readline().decode("ascii", errors="replace").strip()
            tokens = line.split()
            if len(tokens) == 3 and tokens[0] == "element" and tokens[1] == "vertex":
                return int(tokens[2])
            if line == "end_header":
                break
    return 0


def _load_colmap(filepath, interval, ts_idx, te_idx, use_radius, radius_sq):
    total     = _count_colmap(filepath)
    max_pts   = max(1, (te_idx - ts_idx + interval - 1) // interval)
    positions = np.empty((max_pts, 3), dtype=np.float32)
    colors    = np.empty((max_pts, 4), dtype=np.float32)
    count     = 0
    data_idx  = 0

    with open(filepath, "r") as f:
        for raw_line in f:
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if data_idx < ts_idx or data_idx >= te_idx:
                data_idx += 1
                continue
            if (data_idx - ts_idx) % interval != 0:
                data_idx += 1
                continue
            parts = line.split()
            if len(parts) < 8:
                data_idx += 1
                continue
            try:
                x = float(parts[1])
                y = float(parts[2])
                z = float(parts[3])
                if use_radius and (x * x + y * y + z * z) > radius_sq:
                    data_idx += 1
                    continue
                positions[count] = (x, y, z)
                colors[count]    = (
                    int(parts[4]) / 255.0,
                    int(parts[5]) / 255.0,
                    int(parts[6]) / 255.0,
                    1.0,
                )
                count += 1
            except (ValueError, IndexError):
                pass
            data_idx += 1

    return positions[:count], colors[:count], total, count


# ============================================================================
# WSPOLNA LOGIKA PARSOWANIA
# ============================================================================

def _parse_file(props, filepath):
    fmt      = detect_format(filepath)
    interval = max(1, props.import_interval)

    if fmt == "colmap":
        total = _count_colmap(filepath)
    elif fmt == "xyz":
        total = count_points_xyz(filepath)
    elif fmt == "ply":
        total = _count_ply_header(filepath)
    elif fmt == "las":
        try:
            import laspy
            with laspy.open(filepath) as lf:
                total = lf.header.point_count
        except Exception:
            total = 0
    else:
        total = 0

    if total == 0:
        raise ValueError("Brak prawidlowych punktow w pliku")

    ts_idx = int(total * props.trim_start_percent / 100.0)
    te_idx = total - int(total * props.trim_end_percent / 100.0)
    if te_idx < ts_idx:
        te_idx = ts_idx

    use_radius = props.use_radius_limit and props.radius_limit > 0.0
    radius_sq  = float(props.radius_limit) ** 2

    if fmt == "colmap":
        return _load_colmap(filepath, interval, ts_idx, te_idx, use_radius, radius_sq)
    if fmt == "xyz":
        return load_xyz(filepath, interval, ts_idx, te_idx, use_radius, radius_sq)
    if fmt == "ply":
        return load_ply(filepath, interval, ts_idx, te_idx, use_radius, radius_sq)
    if fmt == "las":
        return load_las(filepath, interval, ts_idx, te_idx, use_radius, radius_sq)


# ============================================================================
# TWORZENIE MESHA
# ============================================================================

def _create_mesh_numpy(context, positions, colors, mesh_name="PointCloud"):
    n               = len(positions)
    collection_name = "Imported_PointCloud"
    collection      = (
        bpy.data.collections.get(collection_name)
        or bpy.data.collections.new(collection_name)
    )
    if collection_name not in context.scene.collection.children:
        context.scene.collection.children.link(collection)

    mesh = bpy.data.meshes.new(mesh_name)
    obj  = bpy.data.objects.new(mesh_name, mesh)
    collection.objects.link(obj)

    mesh.vertices.add(n)
    mesh.vertices.foreach_set("co", positions.ravel())

    if not mesh.color_attributes:
        color_attr = mesh.color_attributes.new(
            name="Col", type="BYTE_COLOR", domain="POINT"
        )
    else:
        color_attr = mesh.color_attributes[0]
    color_attr.data.foreach_set("color", colors.ravel())

    mesh.update()
    context.view_layer.objects.active = obj
    obj.select_set(True)
    return obj


# ============================================================================
# EKSPORT - funkcje pomocnicze (numpy vectorized)
# ============================================================================

def _get_colors_numpy(mesh, force_grey=False):
    n = len(mesh.vertices)
    if force_grey:
        grey = np.full((n, 3), 128, dtype=np.uint8)
        return grey

    # Szukaj atrybutu "Col" (nasz atrybut), potem active
    color_attr = mesh.color_attributes.get("Col") or mesh.color_attributes.active
    if color_attr is None:
        return np.full((n, 3), 128, dtype=np.uint8)

    raw = np.empty(n * 4, dtype=np.float32)
    color_attr.data.foreach_get("color", raw)
    rgba = raw.reshape(-1, 4)
    rgb  = (rgba[:, :3] * 255.0).clip(0, 255).astype(np.uint8)
    return rgb


def _apply_modifiers_to_mesh(context, obj):
    # Duplikuj obiekt zeby nie niszczyc oryginalu
    dup = obj.copy()
    dup.data = obj.data.copy()
    context.collection.objects.link(dup)

    # Odznacz wszystko, aktywuj duplikat
    bpy.ops.object.select_all(action="DESELECT")
    dup.select_set(True)
    context.view_layer.objects.active = dup

    # Krok 1: konwertuj na PointCloud (aplikuje modyfikatory GeoNodes)
    bpy.ops.object.convert(target="POINTCLOUD")

    # Krok 2: konwertuj na Mesh (werteksy dostepne do eksportu)
    bpy.ops.object.convert(target="MESH")

    return dup


def _write_colmap_numpy(filepath, coords_w, colors_rgb):
    n   = len(coords_w)
    buf = io.StringIO()
    buf.write("# 3D point list with one line of data per point\n")
    buf.write("# POINT_ID, X, Y, Z, R, G, B, ERROR\n")

    ids  = np.arange(n, dtype=np.int32)
    data = np.column_stack([
        ids.astype(str).tolist() if False else ids,
        coords_w.astype(np.float64),
        colors_rgb.astype(np.int32),
    ])

    # Vectorized formatting - znacznie szybsze niz petla
    rows = np.column_stack((ids, coords_w, colors_rgb))
    fmt  = "%d %.6f %.6f %.6f %d %d %d 0"
    np.savetxt(buf, rows, fmt=fmt)

    with open(filepath, "w") as f:
        f.write("# 3D point list with one line of data per point\n")
        f.write("# POINT_ID, X, Y, Z, R, G, B, ERROR\n")
        f.write(buf.getvalue())

    return n


# ============================================================================
# WLASCIWOSCI
# ============================================================================

class ColmapProperties(bpy.types.PropertyGroup):
    filepath: StringProperty(
        name="File Path",
        description="Sciezka do pliku chmury punktow (.txt COLMAP, .ply, .xyz, .las, .laz)",
        default="",
        subtype="FILE_PATH",
    )
    import_interval: IntProperty(
        name="Import Interval",
        description="Wczytuj co N-ty punkt (1=wszystkie, 5=co piaty)",
        default=5, min=1, max=1000,
    )
    trim_start_percent: FloatProperty(
        name="Trim Start (%)",
        description="Pomin pierwsze X% punktow z pliku",
        default=0.0, min=0.0, max=100.0, precision=1, subtype="PERCENTAGE",
    )
    trim_end_percent: FloatProperty(
        name="Trim End (%)",
        description="Pomin ostatnie X% punktow z pliku",
        default=0.0, min=0.0, max=100.0, precision=1, subtype="PERCENTAGE",
    )
    use_radius_limit: BoolProperty(
        name="Use Radius Limit",
        description="Filtruj punkty poza promieniem od poczatku ukladu",
        default=False,
    )
    radius_limit: FloatProperty(
        name="Radius Limit (m)",
        description="Maksymalna odleglosc od poczatku ukladu wspolrzednych",
        default=10.0, min=0.1, max=10000.0, precision=2, unit="LENGTH",
    )
    point_size: FloatProperty(
        name="Point Size",
        description="Rozmiar wyswietlanych punktow",
        default=0.01, min=0.001, max=1.0, precision=3,
    )
    total_points:    IntProperty(name="Total Points",    default=0)
    imported_points: IntProperty(name="Imported Points", default=0)


# ============================================================================
# OPERATOR IMPORTU (szybki, blokujacy)
# ============================================================================

class COLMAP_OT_ImportPointCloud(bpy.types.Operator):
    bl_idname  = "import_scene.colmap_pointcloud"
    bl_label   = "Import Point Cloud"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props    = context.scene.colmap_props
        filepath = bpy.path.abspath(props.filepath)

        if not filepath:
            self.report({"ERROR"}, "Sciezka pliku jest pusta.")
            return {"CANCELLED"}
        if not os.path.exists(filepath):
            self.report({"ERROR"}, f"Plik nie istnieje: {filepath}")
            return {"CANCELLED"}

        fmt = detect_format(filepath)
        self.report({"INFO"}, f"Wykryty format: {fmt.upper()}")

        try:
            positions, colors, total, count = _parse_file(props, filepath)
        except Exception as e:
            self.report({"ERROR"}, f"Blad importu: {str(e)}")
            return {"CANCELLED"}

        props.total_points    = total
        props.imported_points = count

        if count == 0:
            self.report({"WARNING"}, "Po filtrowaniu nie pozostaly zadne punkty.")
            return {"CANCELLED"}

        base = os.path.splitext(os.path.basename(filepath))[0]
        _create_mesh_numpy(context, positions, colors, mesh_name=base)
        self.report({"INFO"}, f"Zaimportowano {count} z {total} punktow ({fmt.upper()})")
        return {"FINISHED"}


# ============================================================================
# OPERATOR IMPORTU MODALNEGO
# ============================================================================

MODAL_CHUNK_LINES = 5000


class COLMAP_OT_ImportPointCloudModal(bpy.types.Operator):
    bl_idname  = "import_scene.colmap_pointcloud_modal"
    bl_label   = "Import Point Cloud (Modal)"
    bl_options = {"REGISTER", "UNDO"}

    _timer               = None
    _file                = None
    _filepath            = ""
    _trim_start_idx      = 0
    _trim_end_idx        = 0
    _interval            = 1
    _use_radius          = False
    _radius_sq           = 0.0
    _current_data_index  = 0
    _positions           = None
    _colors              = None
    _count               = 0

    def invoke(self, context, event):
        props    = context.scene.colmap_props
        filepath = bpy.path.abspath(props.filepath)

        if not filepath or not os.path.exists(filepath):
            self.report({"ERROR"}, "Nieprawidlowa sciezka pliku.")
            return {"CANCELLED"}

        fmt = detect_format(filepath)
        if fmt != "colmap":
            self.report({"INFO"}, f"Format {fmt.upper()} - uzywam szybkiego importu.")
            return bpy.ops.import_scene.colmap_pointcloud("EXEC_DEFAULT")

        total = _count_colmap(filepath)
        if total == 0:
            self.report({"ERROR"}, "Brak prawidlowych punktow w pliku COLMAP.")
            return {"CANCELLED"}

        props.total_points   = total
        interval             = max(1, props.import_interval)
        ts_idx               = int(total * props.trim_start_percent / 100.0)
        te_idx               = total - int(total * props.trim_end_percent / 100.0)
        if te_idx < ts_idx:
            te_idx = ts_idx

        max_pts              = max(1, (te_idx - ts_idx + interval - 1) // interval)
        self._positions      = np.empty((max_pts, 3), dtype=np.float32)
        self._colors         = np.empty((max_pts, 4), dtype=np.float32)
        self._count          = 0
        self._interval       = interval
        self._trim_start_idx = ts_idx
        self._trim_end_idx   = te_idx
        self._use_radius     = props.use_radius_limit and props.radius_limit > 0.0
        self._radius_sq      = float(props.radius_limit) ** 2
        self._current_data_index = 0
        self._filepath       = filepath

        self._file  = open(filepath, "r")
        self._timer = context.window_manager.event_timer_add(0.01, window=context.window)
        context.window_manager.modal_handler_add(self)
        context.scene.colmap_status   = "Importowanie COLMAP..."
        context.scene.colmap_progress = 0.0
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if event.type in {"ESC", "RIGHTMOUSE"}:
            self.cancel(context)
            self.report({"INFO"}, "Import anulowany.")
            return {"CANCELLED"}

        if event.type == "TIMER":
            done = self._process_chunk(context)
            if done:
                self._cleanup(context)
                props = context.scene.colmap_props
                count = self._count
                props.imported_points = count
                if count > 0:
                    base = os.path.splitext(os.path.basename(self._filepath))[0]
                    _create_mesh_numpy(
                        context,
                        self._positions[:count],
                        self._colors[:count],
                        mesh_name=base,
                    )
                    context.scene.colmap_status = f"Gotowe: {count} punktow"
                    self.report({"INFO"}, f"Zaimportowano {count} punktow (COLMAP modal)")
                else:
                    context.scene.colmap_status = "Brak punktow po filtrowaniu"
                context.scene.colmap_progress = 1.0
                return {"FINISHED"}

        return {"PASS_THROUGH"}

    def _process_chunk(self, context):
        lines_done = 0
        while lines_done < MODAL_CHUNK_LINES:
            raw_line = self._file.readline()
            if not raw_line:
                return True
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            di = self._current_data_index
            if di < self._trim_start_idx or di >= self._trim_end_idx:
                self._current_data_index += 1
                continue
            if (di - self._trim_start_idx) % self._interval != 0:
                self._current_data_index += 1
                continue
            parts = line.split()
            if len(parts) < 8:
                self._current_data_index += 1
                continue
            try:
                x = float(parts[1])
                y = float(parts[2])
                z = float(parts[3])
                if self._use_radius and (x * x + y * y + z * z) > self._radius_sq:
                    self._current_data_index += 1
                    continue
                c = self._count
                self._positions[c] = (x, y, z)
                self._colors[c]    = (
                    int(parts[4]) / 255.0,
                    int(parts[5]) / 255.0,
                    int(parts[6]) / 255.0,
                    1.0,
                )
                self._count += 1
            except (ValueError, IndexError):
                pass
            self._current_data_index += 1
            lines_done += 1

        span = self._trim_end_idx - self._trim_start_idx
        if span > 0:
            done = min(span, max(0, self._current_data_index - self._trim_start_idx))
            context.scene.colmap_progress = done / span
            context.scene.colmap_status   = f"Importowanie... {int(done / span * 100)}%"
        return False

    def _cleanup(self, context):
        wm = context.window_manager
        if self._timer:
            wm.event_timer_remove(self._timer)
        if self._file:
            try:
                self._file.close()
            except Exception:
                pass
        self._timer = None
        self._file  = None

    def cancel(self, context):
        context.scene.colmap_status = "Import anulowany"
        self._cleanup(context)


# ============================================================================
# OPERATOR WIZUALIZACJI
# ============================================================================

class COLMAP_OT_SetupVisualization(bpy.types.Operator):
    bl_idname  = "object.colmap_setup_visualization"
    bl_label   = "Setup PointCloud Visualization"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return (
            context.active_object is not None
            and context.active_object.type == "MESH"
        )

    def execute(self, context):
        obj        = context.active_object
        addon_dir  = os.path.dirname(os.path.abspath(__file__))
        blend_path = os.path.join(addon_dir, "PointCloudFilter.blend")

        if not os.path.exists(blend_path):
            self.report({"ERROR"}, f"PointCloudFilter.blend nie znaleziony: {blend_path}")
            return {"CANCELLED"}

        mat_name = "PointCloudColouring"
        ng_name  = "PointCloud_ClipBox"

        if bpy.data.materials.get(mat_name) is None:
            mat_dir = blend_path + "\\Material\\"
            try:
                bpy.ops.wm.append(
                    filepath=mat_dir + mat_name,
                    directory=mat_dir,
                    filename=mat_name,
                )
            except Exception as e:
                self.report({"ERROR"}, f"Blad dolaczania materialu: {e}")
                return {"CANCELLED"}

        if bpy.data.node_groups.get(ng_name) is None:
            nt_dir = blend_path + "\\NodeTree\\"
            try:
                bpy.ops.wm.append(
                    filepath=nt_dir + ng_name,
                    directory=nt_dir,
                    filename=ng_name,
                )
            except Exception as e:
                self.report({"ERROR"}, f"Blad dolaczania node group: {e}")
                return {"CANCELLED"}

        mat        = bpy.data.materials.get(mat_name)
        node_group = bpy.data.node_groups.get(ng_name)
        if not mat or not node_group:
            self.report({"ERROR"}, "Nie udalo sie zaladowac zasobow z PointCloudFilter.blend")
            return {"CANCELLED"}

        if len(obj.material_slots) == 0:
            obj.data.materials.append(None)
        obj.material_slots[0].link     = "OBJECT"
        obj.material_slots[0].material = mat

        existing = next(
            (m for m in obj.modifiers
             if m.type == "NODES" and m.node_group == node_group),
            None,
        )
        if not existing:
            mod = obj.modifiers.new(name="PointCloud_ClipBox", type="NODES")
            mod.node_group = node_group
        else:
            mod = existing
        obj.modifiers.active = mod

        for area in context.screen.areas:
            if area.type == "PROPERTIES":
                for space in area.spaces:
                    if space.type == "PROPERTIES":
                        space.context = "MODIFIER"
                        break
                break

        self.report({"INFO"}, f"Zastosowano '{mat_name}' i '{ng_name}' do '{obj.name}'")
        return {"FINISHED"}


# ============================================================================
# OPERATOR EKSPORTU (COLMAP points3D.txt) - numpy vectorized
#
# Sekwencja konwersji przed eksportem:
#   duplikat -> convert(POINTCLOUD) -> convert(MESH) -> numpy export
#   Dzieki temu modyfikatory GeoNodes sa prawidlowo aplikowane.
#
# Opcja export_grey: wszystkie punkty eksportowane jako szary 50% (128 128 128)
# ============================================================================

class COLMAP_OT_ExportPointCloud(bpy.types.Operator):
    bl_idname  = "export_scene.colmap_pointcloud"
    bl_label   = "Export COLMAP Point Cloud"
    bl_options = {"REGISTER"}

    filepath:    StringProperty(
        name="File Path",
        default="points3D.txt",
        subtype="FILE_PATH",
    )
    filter_glob: StringProperty(default="*.txt", options={"HIDDEN"})

    export_grey: BoolProperty(
        name="Eksportuj jako szary 50%",
        description="Zastap kolory punktow stalym szarym (128 128 128)",
        default=False,
    )

    @classmethod
    def poll(cls, context):
        return (
            context.active_object is not None
            and context.active_object.type == "MESH"
        )

    def invoke(self, context, event):
        # Ustaw domyslna nazwe pliku z katalogiem biezacego pliku .blend
        if not self.filepath or self.filepath == "points3D.txt":
            blend_dir = bpy.path.abspath("//")
            if not blend_dir:
                blend_dir = os.path.expanduser("~")
            self.filepath = os.path.join(blend_dir, "points3D.txt")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def draw(self, context):
        self.layout.prop(self, "export_grey")

    def execute(self, context):
        orig_obj    = context.active_object
        orig_active = context.view_layer.objects.active
        orig_selected = [o for o in context.selected_objects]

        dup = None
        try:
            # --- Duplikuj i zastosuj modyfikatory przez sekwencje konwersji ---
            dup = orig_obj.copy()
            dup.data = orig_obj.data.copy()
            context.collection.objects.link(dup)

            bpy.ops.object.select_all(action="DESELECT")
            dup.select_set(True)
            context.view_layer.objects.active = dup

            # Krok 1: MESH -> POINTCLOUD  (aplikuje GeoNodes PointCloud_ClipBox)
            bpy.ops.object.convert(target="POINTCLOUD")

            # Krok 2: POINTCLOUD -> MESH  (werteksy dostepne przez foreach_get)
            bpy.ops.object.convert(target="MESH")

            mesh   = context.view_layer.objects.active.data
            n      = len(mesh.vertices)
            matrix = orig_obj.matrix_world

            if n == 0:
                self.report({"WARNING"}, "Brak werteksow po aplikacji modyfikatorow.")
                return {"CANCELLED"}

            # --- XYZ numpy (foreach_get ~50x szybciej niz petla) ---
            raw_co = np.empty(n * 3, dtype=np.float32)
            mesh.vertices.foreach_get("co", raw_co)
            coords = raw_co.reshape(-1, 3)

            # Aplikuj macierz swiata wektorowo
            mat   = np.array(matrix, dtype=np.float64)[:3, :]
            ones  = np.ones((n, 1), dtype=np.float64)
            ch    = np.hstack([coords.astype(np.float64), ones])
            world = (mat @ ch.T).T

            # --- Kolory numpy ---
            colors_rgb = _get_colors_numpy(mesh, force_grey=self.export_grey)

            # --- Zapis numpy vectorized ---
            rows = np.column_stack([
                np.arange(n, dtype=np.int32),
                world,
                colors_rgb.astype(np.int32),
            ])
            fmt = "%d %.6f %.6f %.6f %d %d %d 0"

            with open(self.filepath, "w") as f:
                f.write("# 3D point list with one line of data per point\n")
                f.write("# POINT_ID, X, Y, Z, R, G, B, ERROR\n")
                buf = io.StringIO()
                np.savetxt(buf, rows, fmt=fmt)
                f.write(buf.getvalue())

            self.report({"INFO"}, f"Wyeksportowano {n} punktow do {self.filepath}")
            return {"FINISHED"}

        except Exception as e:
            self.report({"ERROR"}, f"Blad eksportu: {e}")
            return {"CANCELLED"}

        finally:
            # Zawsze przywroc stan sceny i usun duplikat
            if dup is not None:
                mesh_data = dup.data if dup.data != orig_obj.data else None
                bpy.data.objects.remove(dup, do_unlink=True)
                if mesh_data is not None:
                    try:
                        bpy.data.meshes.remove(mesh_data)
                    except Exception:
                        pass
            bpy.ops.object.select_all(action="DESELECT")
            for o in orig_selected:
                try:
                    o.select_set(True)
                except Exception:
                    pass
            context.view_layer.objects.active = orig_active


# ============================================================================
# PANEL UI
# ============================================================================

class COLMAP_PT_MainPanel(bpy.types.Panel):
    bl_label       = "LiDAR Point Cloud Tools"
    bl_idname      = "LiDAR_PT_main_panel"
    bl_space_type  = "VIEW_3D"
    bl_region_type = "UI"
    bl_category    = "LiDAR"

    def draw(self, context):
        layout = self.layout
        props  = context.scene.colmap_props

        box = layout.box()
        box.label(text="Import Settings", icon="IMPORT")
        box.prop(props, "filepath", text="File Path")
        box.label(text="Formats: .txt (COLMAP) | .ply | .xyz | .las | .laz", icon="INFO")
        box.prop(props, "import_interval")

        col = box.column(align=True)
        col.label(text="Trim Range (%):")
        col.prop(props, "trim_start_percent", text="Start")
        col.prop(props, "trim_end_percent",   text="End")

        row = box.row(align=True)
        row.prop(props, "use_radius_limit", text="Use Radius")
        row.prop(props, "radius_limit")

        box.operator(
            "import_scene.colmap_pointcloud",
            text="Import Point Cloud",
            icon="FILE_REFRESH",
        )
        box.operator(
            "import_scene.colmap_pointcloud_modal",
            text="Import Point Cloud (Modal)",
            icon="TIME",
        )

        if context.scene.colmap_status:
            box.label(text=context.scene.colmap_status)
        box.prop(context.scene, "colmap_progress", text="Progress")

        if props.total_points > 0:
            sb = box.box()
            sb.label(text=f"Total Points:  {props.total_points}")
            sb.label(text=f"Imported:      {props.imported_points}")
            pct = (
                props.imported_points / props.total_points * 100
                if props.total_points else 0
            )
            sb.label(text=f"Filter Rate:   {pct:.1f}%")

        layout.separator()

        box = layout.box()
        box.label(text="Visualization", icon="OUTLINER_OB_POINTCLOUD")
        box.operator(
            "object.colmap_setup_visualization",
            text="Apply Filter & Material",
            icon="GEOMETRY_NODES",
        )

        box = layout.box()
        box.label(text="Export", icon="EXPORT")
        box.operator(
            "export_scene.colmap_pointcloud",
            text="Export Point Cloud (COLMAP)",
            icon="FILEBROWSER",
        )
        if context.active_object:
            box.label(text=f"Active: {context.active_object.name}", icon="OBJECT_DATA")


# ============================================================================
# REJESTRACJA
# ============================================================================

classes = (
    ColmapProperties,
    COLMAP_OT_ImportPointCloud,
    COLMAP_OT_ImportPointCloudModal,
    COLMAP_OT_SetupVisualization,
    COLMAP_OT_ExportPointCloud,
    COLMAP_PT_MainPanel,
)


def register():
    ensure_laspy()
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.colmap_props = bpy.props.PointerProperty(type=ColmapProperties)
    bpy.types.Scene.colmap_progress = bpy.props.FloatProperty(
        name="COLMAP Import Progress",
        default=0.0, min=0.0, max=1.0,
    )
    bpy.types.Scene.colmap_status = bpy.props.StringProperty(
        name="COLMAP Status",
        default="",
    )


def unregister():
    del bpy.types.Scene.colmap_progress
    del bpy.types.Scene.colmap_status
    del bpy.types.Scene.colmap_props
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()