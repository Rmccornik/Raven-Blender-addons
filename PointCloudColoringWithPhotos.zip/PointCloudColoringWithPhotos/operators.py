import bpy
import time
from . import utils

class LIDAR_OT_set_display_mode(bpy.types.Operator):
    bl_idname = "lidar.set_display_mode"
    bl_label = "Set Display Mode"
    
    def execute(self, context):
        scene = context.scene
        mesh_obj = scene.lidar_proj_object
        if not mesh_obj:
            return {'CANCELLED'}
            
        mode = scene.lidar_proj_display_mode
        pc_name = f"{mesh_obj.name}_PC"
        pc_obj = bpy.data.objects.get(pc_name)
        
        if mode == 'A':
            if pc_obj:
                bpy.data.objects.remove(pc_obj, do_unlink=True)
            mesh_obj.hide_viewport = False
        else:
            if not pc_obj:
                pc_mesh = bpy.data.meshes.new(pc_name)
                pc_mesh.from_pydata([(0, 0, 0)], [],[]) 
                pc_obj = bpy.data.objects.new(pc_name, pc_mesh)
                context.collection.objects.link(pc_obj)
                
                # Pierwszy modyfikator: generowanie bazy z oryginalnego obiektu MESH
                mod_base = pc_obj.modifiers.new(name="Lidar_Base_Points", type='NODES')
                mod_base.node_group = utils.create_base_gn_tree()
                utils.set_modifier_input(mod_base, "Source Object", mesh_obj)
                
                # Drugi modyfikator: Wizualizator użytkownika
                utils.load_assets_from_blend()
                mod_wiz = pc_obj.modifiers.new(name="WizualizerPunktow", type='NODES')
                if 'WizualizerPunktow' in bpy.data.node_groups:
                    mod_wiz.node_group = bpy.data.node_groups['WizualizerPunktow']
                
                # Przypisanie materiału do bazy PointCloud
                if 'KoloryPunktow' in bpy.data.materials:
                    pc_obj.data.materials.append(bpy.data.materials['KoloryPunktow'])
            
            mesh_obj.hide_viewport = (mode == 'C')
            pc_obj.hide_viewport = False
            
            bpy.ops.object.select_all(action='DESELECT')
            pc_obj.select_set(True)
            context.view_layer.objects.active = pc_obj
            
            utils.update_gn_inputs(scene, pc_obj)
            
            for area in context.screen.areas:
                if area.type == 'PROPERTIES':
                    area.spaces.active.context = 'MODIFIER'
            
            pc_obj.select_set(False)
            pc_obj.select_set(True)
            
        utils.tag_redraw_all()
        return {'FINISHED'}

class LIDAR_OT_reset_colors(bpy.types.Operator):
    bl_idname = "lidar.reset_colors"
    bl_label = "Reset Colours"
    bl_options = {'REGISTER', 'UNDO'}
    
    def invoke(self, context, event):
        mesh_obj = context.scene.lidar_proj_object
        if mesh_obj and len(mesh_obj.data.vertices) > 1000000:
            return context.window_manager.invoke_confirm(self, event)
        return self.execute(context)
        
    def execute(self, context):
        mesh_obj = context.scene.lidar_proj_object
        if not mesh_obj:
            self.report({'WARNING'}, "No MESH object selected.")
            return {'CANCELLED'}
            
        utils.ensure_attributes(mesh_obj)
        mesh = mesh_obj.data
        n = len(mesh.vertices)
        
        import numpy as np
        col_buf = np.ones(n * 4, dtype=np.float32)
        mesh.attributes['Col'].data.foreach_set('color', col_buf)
        
        score_buf = np.full(n, 100.0, dtype=np.float32)
        mesh.attributes['Score'].data.foreach_set('value', score_buf)
        
        mesh.update()
        utils.tag_redraw_all()
        return {'FINISHED'}

class LIDAR_OT_project_active_camera(bpy.types.Operator):
    bl_idname = "lidar.project_active_camera"
    bl_label = "Project Active Camera"
    
    def execute(self, context):
        mesh_obj = context.scene.lidar_proj_object
        cam = context.scene.camera
        
        if not mesh_obj or not cam:
            self.report({'WARNING'}, "Mesh or Active Camera missing.")
            return {'CANCELLED'}
            
        utils.ensure_attributes(mesh_obj)
        
        t0 = time.perf_counter()
        data, count, pct = utils.run_single_camera_projection(context, cam, mesh_obj)
        
        if data:
            mesh = mesh_obj.data
            mesh.attributes['Col'].data.foreach_set('color', data[2].ravel())
            mesh.attributes['Score'].data.foreach_set('value', data[1])
            mesh.update()
            
        elapsed = time.perf_counter() - t0
        utils.update_log(context, f"Action: Active Cam\nCam: {cam.name}\nPoints: {count} ({pct:.2f}%)\nTime: {elapsed:.2f}s")
        utils.tag_redraw_all()
        
        return {'FINISHED'}

class LIDAR_OT_sequential_project(bpy.types.Operator):
    bl_idname = "lidar.sequential_project"
    bl_label = "Sequential Projection"
    
    def invoke(self, context, event):
        self.mesh_obj = context.scene.lidar_proj_object
        if not self.mesh_obj:
            self.report({'WARNING'}, "No MESH object selected.")
            return {'CANCELLED'}
            
        self.camera_list = utils.build_camera_list(context)
        if not self.camera_list:
            self.report({'WARNING'}, "No cameras found based on criteria.")
            return {'CANCELLED'}
            
        if len(self.camera_list) > 50 and not getattr(self, "confirmed", False):
            self.confirmed = True
            return context.window_manager.invoke_confirm(self, event)
            
        utils.ensure_attributes(self.mesh_obj)
        
        wm = context.window_manager
        wm.lidar_proj_stop = False
        wm.lidar_proj_running = True
        wm.progress_begin(0, len(self.camera_list))
        
        self.current_index = 0
        self.total_time = 0.0
        self.persistent_data = None
        self.timer = wm.event_timer_add(0.01, window=context.window)
        
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        wm = context.window_manager
        
        if event.type == 'TIMER':
            if wm.lidar_proj_stop or self.current_index >= len(self.camera_list):
                if self.persistent_data:
                    mesh = self.mesh_obj.data
                    mesh.attributes['Col'].data.foreach_set('color', self.persistent_data[2].ravel())
                    mesh.attributes['Score'].data.foreach_set('value', self.persistent_data[1])
                    mesh.update()
                    
                wm.event_timer_remove(self.timer)
                wm.progress_end()
                wm.lidar_proj_running = False
                
                msg = "Done" if self.current_index >= len(self.camera_list) else "Stopped"
                utils.update_log(context, f"{msg}.\nTotal Time: {self.total_time:.2f}s\nCameras: {self.current_index}/{len(self.camera_list)}")
                utils.tag_redraw_all()
                return {'FINISHED'}

            cam = self.camera_list[self.current_index]
            t0 = time.perf_counter()
            
            try:
                self.persistent_data, count, pct = utils.run_single_camera_projection(
                    context, cam, self.mesh_obj, self.persistent_data
                )
                
                mesh = self.mesh_obj.data
                mesh.attributes['Col'].data.foreach_set('color', self.persistent_data[2].ravel())
                mesh.attributes['Score'].data.foreach_set('value', self.persistent_data[1])
                mesh.update()
                
            except Exception as e:
                import traceback
                print(f"Error processing {cam.name}:\n{traceback.format_exc()}")
                count, pct = 0, 0.0
                
            elapsed = time.perf_counter() - t0
            self.total_time += elapsed
            
            wm.progress_update(self.current_index + 1)
            
            log_str = (
                f"Action: Sequential Run\n"
                f"Cam: {cam.name} ({self.current_index + 1}/{len(self.camera_list)})\n"
                f"Points updated: {count} ({pct:.2f}%)\n"
                f"Elapsed: {elapsed:.2f}s (Total: {self.total_time:.2f}s)"
            )
            utils.update_log(context, log_str)
            
            self.current_index += 1
            utils.tag_redraw_all()
            
        return {'PASS_THROUGH'}

class LIDAR_OT_stop_projection(bpy.types.Operator):
    bl_idname = "lidar.stop_projection"
    bl_label = "Stop"
    
    def execute(self, context):
        context.window_manager.lidar_proj_stop = True
        return {'FINISHED'}