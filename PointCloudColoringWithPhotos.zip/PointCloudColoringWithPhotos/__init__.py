bl_info = {
    "name": "Lidar Proj",
    "description": "Projects colors from cameras onto a dense point cloud mesh.",
    "author": "Twoje Imię",
    "version": (4, 0),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar > Lidar Proj",
    "category": "3D View",
}

import bpy
from bpy.props import (
    PointerProperty, EnumProperty, FloatProperty,
    IntProperty, BoolProperty, StringProperty
)
from . import operators, ui, utils

def _poll_mesh(self, object):
    return object.type == 'MESH'

def update_display_mode(self, context):
    bpy.ops.lidar.set_display_mode()

def update_gn_modifiers(self, context):
    scene = context.scene
    mesh_obj = scene.lidar_proj_object
    if not mesh_obj: return
    pc_name = f"{mesh_obj.name}_PC"
    pc_obj = bpy.data.objects.get(pc_name)
    if pc_obj:
        utils.update_gn_inputs(scene, pc_obj)

classes = (
    operators.LIDAR_OT_project_active_camera,
    operators.LIDAR_OT_sequential_project,
    operators.LIDAR_OT_stop_projection,
    operators.LIDAR_OT_reset_colors,
    operators.LIDAR_OT_set_display_mode,
    ui.LIDAR_PT_main,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
        
    bpy.types.Scene.lidar_proj_object = PointerProperty(
        name="Object", type=bpy.types.Object, poll=_poll_mesh
    )
    bpy.types.Scene.lidar_proj_display_mode = EnumProperty(
        name="Display Mode",
        items=[
            ('A', "Mesh Only", "MESH visible, companion hidden/deleted"),
            ('B', "Both", "Both objects visible"),
            ('C', "PointCloud Only", "MESH hidden, companion visible")
        ],
        default='A',
        update=update_display_mode
    )
    
    # GN Properties
    bpy.types.Scene.lidar_proj_radius = FloatProperty(
        name="Radius", default=2.0, min=0.3, max=30.0, update=update_gn_modifiers
    )
    bpy.types.Scene.lidar_proj_emissive = BoolProperty(
        name="Emissive", default=False, update=update_gn_modifiers
    )
    bpy.types.Scene.lidar_proj_vdistance = BoolProperty(
        name="VDistance", default=False, update=update_gn_modifiers
    )
    bpy.types.Scene.lidar_proj_transp = FloatProperty(
        name="Transp", default=0.0, min=0.0, max=100.0, update=update_gn_modifiers
    )

    # Projection Settings
    bpy.types.Scene.lidar_proj_depth_res = EnumProperty(
        name="Depth Map Resolution",
        items=[
            ('5', "5%", ""), ('10', "10%", ""), ('20', "20%", ""),
            ('33', "33%", ""), ('50', "50%", ""), ('100', "100%", "")
        ],
        default='20'
    )
    bpy.types.Scene.lidar_proj_penetration = FloatProperty(
        name="Penetration Depth", default=0.030, min=0.0, max=0.250, step=0.001
    )
    bpy.types.Scene.lidar_proj_strip_width = IntProperty(
        name="Central Strip Width %", default=100, min=1, max=100
    )
    bpy.types.Scene.lidar_proj_cam_source = EnumProperty(
        name="Camera Source",
        items=[
            ('ACTIVE', "Active", "Current active camera only"),
            ('SELECTED', "Selected", "Cameras in viewport selection"),
            ('ALL', "All", "All camera objects in scene")
        ],
        default='ALL'
    )
    bpy.types.Scene.lidar_proj_interval = IntProperty(
        name="Interval", default=1, min=1, max=1000
    )
    
    bpy.types.WindowManager.lidar_proj_running = BoolProperty(default=False)
    bpy.types.WindowManager.lidar_proj_stop = BoolProperty(default=False)
    bpy.types.WindowManager.lidar_proj_log = StringProperty(default="Ready")

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
        
    del bpy.types.Scene.lidar_proj_object
    del bpy.types.Scene.lidar_proj_display_mode
    del bpy.types.Scene.lidar_proj_radius
    del bpy.types.Scene.lidar_proj_emissive
    del bpy.types.Scene.lidar_proj_vdistance
    del bpy.types.Scene.lidar_proj_transp
    del bpy.types.Scene.lidar_proj_depth_res
    del bpy.types.Scene.lidar_proj_penetration
    del bpy.types.Scene.lidar_proj_strip_width
    del bpy.types.Scene.lidar_proj_cam_source
    del bpy.types.Scene.lidar_proj_interval
    
    del bpy.types.WindowManager.lidar_proj_running
    del bpy.types.WindowManager.lidar_proj_stop
    del bpy.types.WindowManager.lidar_proj_log

if __name__ == "__main__":
    register()