import bpy
import numpy as np
import time
import gc
from pathlib import Path

def update_log(context, message):
    context.window_manager.lidar_proj_log = message

def tag_redraw_all():
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

def create_base_gn_tree():
    """Tworzy bazowy węzeł GN: MESH -> PointCloud w locie."""
    tree_name = "Lidar_Base_Points"
    if tree_name in bpy.data.node_groups:
        return bpy.data.node_groups[tree_name]
        
    tree = bpy.data.node_groups.new(tree_name, 'GeometryNodeTree')
    tree.is_modifier = True
    
    # Budowa interfejsu grupy (Blender 4.0+)
    tree.interface.new_socket("Geometry", in_out='IN', socket_type='NodeSocketGeometry')
    tree.interface.new_socket("Source Object", in_out='IN', socket_type='NodeSocketObject')
    tree.interface.new_socket("Geometry", in_out='OUT', socket_type='NodeSocketGeometry')
    
    nodes = tree.nodes
    links = tree.links
    
    in_node = nodes.new('NodeGroupInput')
    out_node = nodes.new('NodeGroupOutput')
    obj_info = nodes.new('GeometryNodeObjectInfo')
    mesh_to_pts = nodes.new('GeometryNodeMeshToPoints')
    
    # Ustawienie względnego pozycjonowania jako domyślne
    obj_info.transform_space = 'RELATIVE'
    
    # Łączenie: Group Input(Target) -> Object Info -> Mesh to Points -> Group Output
    links.new(in_node.outputs["Source Object"], obj_info.inputs["Object"])
    links.new(obj_info.outputs["Geometry"], mesh_to_pts.inputs["Mesh"])
    links.new(mesh_to_pts.outputs["Points"], out_node.inputs["Geometry"])
    
    return tree

def set_modifier_input(mod, name_to_find, value):
    """Pomocnicza funkcja znajdująca identifier gniazda po jego nazwie (Blender 4.0+)."""
    if not mod.node_group: return
    for item in mod.node_group.interface.items_tree:
        if item.item_type == 'SOCKET' and item.name.lower() == name_to_find.lower():
            mod[item.identifier] = value
            break

def update_gn_inputs(scene, pc_obj):
    mod = pc_obj.modifiers.get("WizualizerPunktow")
    if mod and mod.node_group:
        set_modifier_input(mod, "radius", scene.lidar_proj_radius)
        set_modifier_input(mod, "emissive", scene.lidar_proj_emissive)
        set_modifier_input(mod, "vdistance", scene.lidar_proj_vdistance)
        set_modifier_input(mod, "transp", scene.lidar_proj_transp)

def ensure_attributes(mesh_obj):
    mesh = mesh_obj.data
    changed = False
    if 'Col' not in mesh.attributes:
        mesh.attributes.new(name='Col', type='FLOAT_COLOR', domain='POINT')
        n = len(mesh.vertices)
        col_buf = np.ones(n * 4, dtype=np.float32)
        mesh.attributes['Col'].data.foreach_set('color', col_buf)
        changed = True
    if 'Score' not in mesh.attributes:
        mesh.attributes.new(name='Score', type='FLOAT', domain='POINT')
        n = len(mesh.vertices)
        score_buf = np.full(n, 100.0, dtype=np.float32)
        mesh.attributes['Score'].data.foreach_set('value', score_buf)
        changed = True
    if changed:
        mesh.update()

def build_camera_list(context):
    scene = context.scene
    src = scene.lidar_proj_cam_source
    if src == 'ACTIVE':
        cameras = [scene.camera] if scene.camera else[]
    elif src == 'SELECTED':
        cameras = [o for o in context.selected_objects if o.type == 'CAMERA']
        if not cameras:
            cameras = [o for o in scene.objects if o.type == 'CAMERA']
    else:
        cameras = [o for o in scene.objects if o.type == 'CAMERA']
        
    cameras.sort(key=lambda c: c.name)
    if src in {'SELECTED', 'ALL'}:
        cameras = cameras[::scene.lidar_proj_interval]
    return cameras

def load_assets_from_blend():
    blend_path = Path(__file__).parent / 'assets' / 'MatGN.blend'
    if not blend_path.exists():
        return
    with bpy.data.libraries.load(str(blend_path), link=False) as (src, dst):
        if 'KoloryPunktow' not in bpy.data.materials and 'KoloryPunktow' in src.materials:
            dst.materials = ['KoloryPunktow']
        if 'WizualizerPunktow' not in bpy.data.node_groups and 'WizualizerPunktow' in src.node_groups:
            dst.node_groups = ['WizualizerPunktow']

def run_single_camera_projection(context, cam_obj, mesh_obj, persistent_data=None):
    scene = context.scene
    render = scene.render
    mesh = mesh_obj.data
    
    if not cam_obj.data.background_images:
        return persistent_data, 0, 0.0

    img = cam_obj.data.background_images[0].image
    if img is None or img.size[0] == 0:
        return persistent_data, 0, 0.0

    res_x = render.resolution_x
    res_y = render.resolution_y
    depsgraph = context.evaluated_depsgraph_get()
    
    proj_mat_mu = cam_obj.calc_matrix_camera(
        depsgraph, x=res_x, y=res_y, scale_x=render.pixel_aspect_x, scale_y=render.pixel_aspect_y
    )
    view_mat_mu = cam_obj.matrix_world.inverted()
    world_mat_mu = mesh_obj.matrix_world

    proj_mat = np.array(proj_mat_mu, dtype=np.float32)
    view_mat = np.array(view_mat_mu, dtype=np.float32)
    world_mat = np.array(world_mat_mu, dtype=np.float32)
    
    n = len(mesh.vertices)
    
    if persistent_data is None:
        pos_buf = np.empty(n * 3, dtype=np.float32)
        mesh.vertices.foreach_get('co', pos_buf)
        P = pos_buf.reshape(n, 3)
        score_buf = np.empty(n, dtype=np.float32)
        mesh.attributes['Score'].data.foreach_get('value', score_buf)
        col_buf = np.empty(n * 4, dtype=np.float32)
        mesh.attributes['Col'].data.foreach_get('color', col_buf)
        col = col_buf.reshape(n, 4)
    else:
        P, score_buf, col = persistent_data

    # 1. Transformacje
    P_h = np.hstack([P, np.ones((n, 1), dtype=np.float32)])
    P_world = (world_mat @ P_h.T).T
    P_cam = (view_mat @ P_world.T).T
    P_clip = (proj_mat @ P_cam.T).T
    
    w = P_clip[:, 3] 
    w_safe = np.where(w == 0, 1e-6, w)
    ndc = P_clip[:, :3] / w_safe[:, None]

    # 2. Widoczność Frustum
    in_frustum = (
        (ndc[:, 0] >= -1) & (ndc[:, 0] <= 1) &
        (ndc[:, 1] >= -1) & (ndc[:, 1] <= 1) &
        (ndc[:, 2] >= 0)  & (ndc[:, 2] <= 1) &
        (w > 0)
    )

    strip_width = scene.lidar_proj_strip_width / 100.0
    if strip_width < 1.0:
        half = strip_width / 2.0
        in_frustum &= (ndc[:, 0] >= -half) & (ndc[:, 0] <= half)

    idx_vis = np.where(in_frustum)[0]
    if len(idx_vis) == 0:
        return (P, score_buf, col), 0, 0.0

    # 3. Z-Buffer: Przygotowanie Sektorów
    depth_res_pct = int(scene.lidar_proj_depth_res) / 100.0
    dm_w = max(1, int(res_x * depth_res_pct))
    dm_h = max(1, int(res_y * depth_res_pct))

    px = ((ndc[idx_vis, 0] + 1.0) * 0.5 * (dm_w - 1)).astype(np.int32).clip(0, dm_w - 1)
    py = ((ndc[idx_vis, 1] + 1.0) * 0.5 * (dm_h - 1)).astype(np.int32).clip(0, dm_h - 1)

    # Obliczamy euklidesową odległość od kamery dla widocznych punktów (nasz właściwy parametr głębokości i score)
    cam_pos = np.array(cam_obj.matrix_world.translation, dtype=np.float32)
    dist_pts = np.linalg.norm(P_world[idx_vis, :3] - cam_pos, axis=1)

    # 4. Z-Buffer: Rastryzacja wektorowa NumPy (BARDZO SZYBKA)
    z_buffer = np.full((dm_h, dm_w), np.inf, dtype=np.float32)
    # Wpisuje najmniejszy 'dist' w dany indeks 'py, px' (1 punkt -> 1 sektor)
    np.minimum.at(z_buffer, (py, px), dist_pts)

    # 5. Odcinanie punktów zasłoniętych (Occlusion Check)
    sector_min_z = z_buffer[py, px]
    unoccluded = dist_pts <= (sector_min_z + scene.lidar_proj_penetration)
    
    idx_col = idx_vis[unoccluded]
    dist_col = dist_pts[unoccluded]

    if len(idx_col) == 0:
        return (P, score_buf, col), 0, 0.0

    # 6. Closest Camera Check 
    update = dist_col < score_buf[idx_col]
    idx_upd = idx_col[update]
    
    if len(idx_upd) == 0:
        return (P, score_buf, col), 0, 0.0

    # 7. Sampling Bilinearny z tła kamery
    img_w, img_h = img.size
    px_img = np.array(img.pixels, dtype=np.float32).reshape(img_h, img_w, 4)

    u = (ndc[idx_upd, 0] + 1.0) * 0.5
    v = (ndc[idx_upd, 1] + 1.0) * 0.5

    fx = u * (img_w - 1)
    fy = v * (img_h - 1)
    x0 = fx.astype(np.int32).clip(0, img_w - 2)
    y0 = fy.astype(np.int32).clip(0, img_h - 2)
    wx = (fx - x0)[:, None]
    wy = (fy - y0)[:, None]

    sampled = ((1-wy)*((1-wx)*px_img[y0, x0] + wx*px_img[y0, x0+1]) +
               wy*((1-wx)*px_img[y0+1, x0] + wx*px_img[y0+1, x0+1]))
    sampled[:, 3] = 1.0

    col[idx_upd] = sampled
    score_buf[idx_upd] = dist_col[update]

    del px_img
    gc.collect()

    return (P, score_buf, col), len(idx_upd), float(len(idx_upd))/n * 100.0