import bpy

class LIDAR_PT_main(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Lidar Proj'
    bl_label = "Lidar Projection"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        wm = context.window_manager

        # Object & Camera
        box = layout.box()
        box.prop(scene, "lidar_proj_object")
        cam_name = scene.camera.name if scene.camera else "None"
        box.label(text=f"Active Cam: {cam_name}")

        # Display Mode & GN Props
        box = layout.box()
        box.prop(scene, "lidar_proj_display_mode", expand=True)
        if scene.lidar_proj_display_mode in {'B', 'C'}:
            row = box.row(align=True)
            row.prop(scene, "lidar_proj_radius")
            row = box.row(align=True)
            row.prop(scene, "lidar_proj_transp")
            row = box.row(align=True)
            row.prop(scene, "lidar_proj_emissive")
            row.prop(scene, "lidar_proj_vdistance")

        # Settings
        box = layout.box()
        box.prop(scene, "lidar_proj_depth_res")
        box.prop(scene, "lidar_proj_penetration")
        box.prop(scene, "lidar_proj_strip_width")

        # Camera Source
        box = layout.box()
        box.prop(scene, "lidar_proj_cam_source")
        if scene.lidar_proj_cam_source in {'SELECTED', 'ALL'}:
            box.prop(scene, "lidar_proj_interval")

        # Actions
        box = layout.box()
        is_running = wm.lidar_proj_running
        
        row = box.row()
        row.enabled = not is_running
        row.operator("lidar.project_active_camera", text="Project Active Camera")
        
        row = box.row()
        row.enabled = not is_running
        row.operator("lidar.sequential_project", text="Sequential Projection")
        
        row = box.row()
        row.enabled = is_running
        row.operator("lidar.stop_projection", text="Stop", icon='CANCEL')
        
        row = box.row()
        row.enabled = not is_running
        row.operator("lidar.reset_colors", text="Reset Colours")

        # Status / Log
        box = layout.box()
        for line in wm.lidar_proj_log.split('\n'):
            box.label(text=line)