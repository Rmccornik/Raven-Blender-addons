# ================================================================
#  Raven Trajectory Visualizer  –  Blender Addon  v2.8
#  Author : rafal.karnicki@pwr.edu.pl + Claude Sonnet 4.6
#  Requires: Blender 4.x / 5.x
#  Tab: "Raven Traj"
#
#  Changes v2.8:
#   [1] Removed "Load images as background" checkbox.
#       New operator "Load Background Images" replaces it –
#       placed above "Match scene proportions" button.
#       Loads images from Folder Left/Right for all matching cameras.
#   [2] All UI labels, button descriptions and bl_info translated to EN.
#       All "JMK6" labels replaced with "Raven" in user-visible text.
# ================================================================

bl_info = {
    "name":        "Raven Trajectory Visualizer",
    "author":      "rafal.karnicki@pwr.edu.pl + Claude Sonnet 4.6",
    "version":     (2, 8, 0),
    "blender":     (4, 0, 0),
    "location":    "View3D > Sidebar (N) > Raven Traj",
    "description": "Raven scanner trajectory visualizer – Left/Right camera placement from timestamps",
    "category":    "Import-Export",
}

import bpy
import math
import os
import re
import json
import bisect
import shutil

from bpy.props import (
    StringProperty, IntProperty, FloatProperty,
    BoolProperty, PointerProperty,
)
from bpy.types import Panel, Operator, PropertyGroup
from mathutils import Vector, Quaternion, Matrix


# ════════════════════════════════════════════════════════════════
#  CONSTANTS
# ════════════════════════════════════════════════════════════════

DEFAULT_CALIB = {
    'left': {
        'transformmatrix': [
            -0.3346185246272386, -0.8191754636353696,  0.46581327026402664, -0.01838108225305667,
             0.0010038535903005, -0.4946179127867798,  -0.8691099542799048, -0.07597274182274345,
             0.9423531372337332, -0.2903526823162245,   0.16633064846117307,-0.04974110350698958,
             0.0, 0.0, 0.0, 1.0,
        ],
        'fx': 1125.7329, 'fy': 1126.1543,
        'cx': 1482.1356, 'cy': 2067.9479,
        'imagewidth': 3600, 'imageheight': 3600,
        'coeff': [-0.03968, -0.00162, 0.00116, -0.000254],
    },
    'right': {
        'transformmatrix': [
            -0.34413206117162587,  0.8205190874432164, -0.45642255817950006,  0.0152248209535647,
            -0.00880809270184385, -0.4889136092980424, -0.8722877393074582,  -0.07844582771695106,
            -0.9388799401290473,  -0.296161965458956,   0.17547805628842705, -0.0496326698289228,
             0.0, 0.0, 0.0, 1.0,
        ],
        'fx': 1125.7802, 'fy': 1126.8334,
        'cx': 1572.8321, 'cy': 1951.0490,
        'imagewidth': 3600, 'imageheight': 3600,
        'coeff': [-0.04455, 0.00602, -0.00281, 0.000451],
    },
}

CCVMAT = Matrix(((-1,  0,  0,  0),
                 ( 0, -1,  0,  0),
                 ( 0,  0,  1,  0),
                 ( 0,  0,  0,  1)))

CAMCONV = (Matrix.Rotation(math.radians(90),  4, 'X') @
           Matrix.Rotation(math.radians(180), 4, 'Y'))

_TS_RE = re.compile(r'(\d{10})[_.]( \d{6})')
_TS_RE = re.compile(r'(\d{10})[_.](\d{6})')


# ════════════════════════════════════════════════════════════════
#  MATRIX HELPERS
# ════════════════════════════════════════════════════════════════

def _apply_local_corrections(M_base: Matrix, rz: float, rx: float, ry: float) -> Matrix:
    M = M_base.copy()
    if rz != 0.0:
        M = M @ Matrix.Rotation(math.radians(rz), 4, 'Z')
    if rx != 0.0:
        M = M @ Matrix.Rotation(math.radians(rx), 4, 'X')
    if ry != 0.0:
        M = M @ Matrix.Rotation(math.radians(ry), 4, 'Y')
    return M


def _base_matrix_to_list(M: Matrix):
    return [M[r][c] for r in range(4) for c in range(4)]


def _list_to_matrix4x4(flat) -> Matrix:
    f = [float(v) for v in flat]
    return Matrix([f[0:4], f[4:8], f[8:12], f[12:16]])


def colmap_to_blender_world(qw, qx, qy, qz, tx, ty, tz) -> Matrix:
    """
    Converts COLMAP pose (world->camera, CV right-down-forward)
    to Blender camera matrix_world (camera->world, Y-up, Z-back).
    """
    q         = Quaternion((qw, qx, qy, qz))
    R_w2c     = q.to_matrix()
    R_c2w     = R_w2c.transposed()
    t_w2c     = Vector((tx, ty, tz))
    pos_world = R_c2w @ (-t_w2c)
    C_CV      = Matrix(((1, 0, 0), (0, -1, 0), (0, 0, -1)))
    R_bl      = R_c2w @ C_CV
    M         = R_bl.to_4x4()
    M.translation = pos_world
    return M


# ════════════════════════════════════════════════════════════════
#  LIVE UPDATE CALLBACKS
# ════════════════════════════════════════════════════════════════

def _update_focal_length(self, context):
    fl = self.cam_focal_length
    for obj in bpy.data.objects:
        if obj.type == 'CAMERA' and obj.name.startswith(('CAML', 'CAMR')):
            obj.data.lens = fl


def _rebuild_cameras(props, side: str):
    prefix = 'CAML' if side == 'left' else 'CAMR'
    rz = getattr(props, f'cam_rz_{side}')
    rx = getattr(props, f'cam_rx_{side}')
    ry = getattr(props, f'cam_ry_{side}')
    for obj in bpy.data.objects:
        if obj.type != 'CAMERA' or not obj.name.startswith(prefix):
            continue
        base_flat = obj.get('jmk6base_matrix')
        if base_flat is None:
            continue
        M_base = _list_to_matrix4x4(base_flat)
        obj.matrix_world = _apply_local_corrections(M_base, rz, rx, ry)


def _update_shift(props, side: str):
    prefix = 'CAML' if side == 'left' else 'CAMR'
    sx = getattr(props, f'cam_sx_{side}')
    sy = getattr(props, f'cam_sy_{side}')
    for obj in bpy.data.objects:
        if obj.type == 'CAMERA' and obj.name.startswith(prefix):
            obj.data.shift_x = sx
            obj.data.shift_y = sy


def _update_shift_scale(self, context):
    scale = self.cam_shift_scale
    for side in ('left', 'right'):
        sx0 = getattr(self, f'cam_sx0_{side}')
        sy0 = getattr(self, f'cam_sy0_{side}')
        setattr(self, f'cam_sx_{side}', sx0 * scale)
        setattr(self, f'cam_sy_{side}', sy0 * scale)
        _update_shift(self, side)


def _update_bg_alpha(self, context):
    alpha = self.cam_bg_alpha
    for obj in bpy.data.objects:
        if obj.type == 'CAMERA' and obj.name.startswith(('CAML', 'CAMR')):
            for bg in obj.data.background_images:
                bg.alpha = alpha


def _update_left_rot(self, context):   _rebuild_cameras(self, 'left')
def _update_right_rot(self, context):  _rebuild_cameras(self, 'right')
def _update_shift_left(self, context):  _update_shift(self, 'left')
def _update_shift_right(self, context): _update_shift(self, 'right')


# ════════════════════════════════════════════════════════════════
#  CALIBRATION LOADER
# ════════════════════════════════════════════════════════════════

def load_calib(filepath: str) -> dict:
    with open(filepath, 'r') as f:
        raw = json.load(f)
    result  = {}
    out     = raw.get('output', {})
    caminfo = raw.get('cameraInfo', {})
    for side in ('left', 'right'):
        entry = {}
        if side in out:
            entry['transformmatrix'] = out[side]['transformmatrix']
        if side in caminfo:
            ci = caminfo[side]
            K  = ci.get('K', [1, 0, 0, 0, 1, 0, 0, 0, 1])
            entry['fx']          = K[0]
            entry['fy']          = K[4]
            entry['cx']          = K[2]
            entry['cy']          = K[5]
            entry['imagewidth']  = ci.get('imagewidth',  3600)
            entry['imageheight'] = ci.get('imageheight', 3600)
            entry['coeff']       = ci.get('coeff', [0, 0, 0, 0])
        result[side] = entry
    return result


# ════════════════════════════════════════════════════════════════
#  TIMESTAMP PARSING
# ════════════════════════════════════════════════════════════════

def parse_timestamp_from_name(filename: str):
    m = _TS_RE.search(filename)
    return float(f'{m.group(1)}.{m.group(2)}') if m else None


def collect_image_timestamps(folder: str) -> list:
    result = []
    if not folder or not os.path.isdir(folder):
        return result
    exts = {'.jpg', '.jpeg', '.png', '.tif', '.tiff'}
    for name in os.listdir(folder):
        if os.path.splitext(name)[1].lower() not in exts:
            continue
        ts = parse_timestamp_from_name(name)
        if ts is not None:
            result.append((ts, os.path.join(folder, name)))
    result.sort(key=lambda x: x[0])
    return result


# ════════════════════════════════════════════════════════════════
#  COLMAP images.txt PARSER
# ════════════════════════════════════════════════════════════════

def parse_colmap_images(filepath: str) -> dict:
    """
    Reads COLMAP images.txt.
    Returns dict { timestamp_float: (qw,qx,qy,qz,tx,ty,tz, cam_id, name) }.
    Key is the numeric timestamp extracted from the NAME field via _TS_RE.
    Comment lines and POINTS2D lines are skipped.
    """
    result = {}
    if not filepath or not os.path.isfile(filepath):
        return result
    with open(filepath, 'r') as f:
        lines = [l.rstrip('\r\n') for l in f]
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        i += 1
        if not line or line.startswith('#'):
            continue
        parts = line.split()
        if len(parts) < 10:
            continue
        try:
            int(parts[0])
            qw, qx, qy, qz = float(parts[1]), float(parts[2]), float(parts[3]), float(parts[4])
            tx, ty, tz      = float(parts[5]), float(parts[6]), float(parts[7])
            cam_id          = int(parts[8])
            name            = parts[9]
        except (ValueError, IndexError):
            continue
        ts = parse_timestamp_from_name(name)
        if ts is not None:
            result[ts] = (qw, qx, qy, qz, tx, ty, tz, cam_id, name)
        if i < len(lines):
            i += 1  # skip POINTS2D line
    return result


# ════════════════════════════════════════════════════════════════
#  TRAJECTORY
# ════════════════════════════════════════════════════════════════

def load_trajectory(filepath: str, step: int = 1) -> list:
    records = []
    with open(filepath, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split()
            if len(parts) < 8:
                continue
            ts, tx, ty, tz, qx, qy, qz, qw = map(float, parts[:8])
            records.append({
                'ts':   ts,
                'pos':  Vector((tx, ty, tz)),
                'quat': Quaternion((qw, qx, qy, qz)),
            })
    return records[::step] if step > 1 else records


def interpolate_pose(records: list, ts: float):
    if not records:
        return None
    timestamps = [r['ts'] for r in records]
    if ts <= timestamps[0]:
        return records[0]['pos'].copy(), records[0]['quat'].copy()
    if ts >= timestamps[-1]:
        return records[-1]['pos'].copy(), records[-1]['quat'].copy()
    idx    = bisect.bisect_left(timestamps, ts)
    r0, r1 = records[idx-1], records[idx]
    factor = (ts - r0['ts']) / (r1['ts'] - r0['ts']) if r1['ts'] != r0['ts'] else 0.0
    return r0['pos'].lerp(r1['pos'], factor), r0['quat'].slerp(r1['quat'], factor)


# ════════════════════════════════════════════════════════════════
#  CAMERA MATRICES (trajectory mode)
# ════════════════════════════════════════════════════════════════

def imu_world_matrix(pos, quat, rx, ry, rz) -> Matrix:
    M = quat.to_matrix().to_4x4()
    M.translation = pos
    return (M
            @ Matrix.Rotation(math.radians(rx), 4, 'X')
            @ Matrix.Rotation(math.radians(ry), 4, 'Y')
            @ Matrix.Rotation(math.radians(rz), 4, 'Z'))


def cam_base_matrix(Mimu: Matrix, Tcamfromimucv: list) -> Matrix:
    Tcv       = _list_to_matrix4x4(Tcamfromimucv)
    Tbl       = CCVMAT @ Tcv @ CCVMAT.inverted()
    Timutocam = Tbl.inverted()
    return Mimu @ Timutocam @ CAMCONV


# ════════════════════════════════════════════════════════════════
#  CREATE BLENDER CAMERA
# ════════════════════════════════════════════════════════════════

def create_blender_camera(name, Mworld, M_base, calibdata, side,
                          shift_x=None, shift_y=None,
                          focal_length_override=None, image_path=None):
    cd = calibdata.get(side, {})
    w  = cd.get('imagewidth',  3600)
    h  = cd.get('imageheight', 3600)
    fx = cd.get('fx', 1125.0)

    if shift_x is None:
        shift_x = cd.get('cx', w / 2.0) / w - 0.5
    if shift_y is None:
        shift_y = 0.5 - cd.get('cy', h / 2.0) / h

    camdata               = bpy.data.cameras.new(name=name)
    camdata.type          = 'PERSP'
    camdata.lens_unit     = 'MILLIMETERS'
    camdata.lens          = focal_length_override if focal_length_override else fx * 36.0 / w
    camdata.sensor_fit    = 'HORIZONTAL'
    camdata.sensor_width  = 36.0
    camdata.clip_start    = 0.01
    camdata.clip_end      = 1000.0
    camdata.shift_x       = shift_x
    camdata.shift_y       = shift_y
    camdata['calib_w']    = w
    camdata['calib_h']    = h

    # Background image is NOT loaded here – use "Load Background Images" operator [1]

    obj                    = bpy.data.objects.new(name, camdata)
    obj.matrix_world       = Mworld
    obj['jmk6base_matrix'] = _base_matrix_to_list(M_base)
    return obj


# ════════════════════════════════════════════════════════════════
#  UTILITIES
# ════════════════════════════════════════════════════════════════

def get_or_create_collection(name: str) -> bpy.types.Collection:
    col = bpy.data.collections.get(name)
    if col is None:
        col = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(col)
    return col


def clear_collection(col: bpy.types.Collection):
    for obj in list(col.objects):
        bpy.data.objects.remove(obj, do_unlink=True)


def calib_to_shift(cd: dict) -> tuple:
    w  = cd.get('imagewidth',  3600)
    h  = cd.get('imageheight', 3600)
    cx = cd.get('cx', w / 2.0)
    cy = cd.get('cy', h / 2.0)
    return cx / w - 0.5, 0.5 - cy / h


# ════════════════════════════════════════════════════════════════
#  PROPERTIES
# ════════════════════════════════════════════════════════════════

class RavenTrajProperties(PropertyGroup):

    trjfilepath:   StringProperty(name="Trajectory file",   subtype='FILE_PATH', default="")
    calibfilepath: StringProperty(
        name="Calibration file",
        description="Optional – overrides built-in Raven default calibration",
        subtype='FILE_PATH', default="",
    )
    step: IntProperty(
        name="Every Nth point",
        description="Trajectory sampling interval (1 = all points)",
        default=10, min=1, max=1000,
    )

    # IMU correction
    imurx: FloatProperty(name="Rx", default=0.0,   min=-180.0, max=180.0, step=100, precision=1, description="IMU correction Rx")
    imury: FloatProperty(name="Ry", default=0.0,   min=-180.0, max=180.0, step=100, precision=1, description="IMU correction Ry – 180° reverses front/back")
    imurz: FloatProperty(name="Rz", default=180.0, min=-180.0, max=180.0, step=100, precision=1, description="IMU correction Rz – horizontal rotation")

    # Image folders
    folder_left:    StringProperty(name="Folder CAM Left",  subtype='DIR_PATH', default="")
    folder_right:   StringProperty(name="Folder CAM Right", subtype='DIR_PATH', default="")
    imgstep:        IntProperty(name="Every Nth image", default=10, min=1, max=1000)
    draw_imu_left:  BoolProperty(name="Left",  default=True)
    draw_imu_right: BoolProperty(name="Right", default=True)

    # Local Roll/Pitch/Yaw corrections – live update
    cam_rz_left:  FloatProperty(name="Roll Left Rz",   default=0.0,  min=-180.0, max=180.0, step=100, precision=1, update=_update_left_rot)
    cam_rz_right: FloatProperty(name="Roll Right Rz",  default=0.0,  min=-180.0, max=180.0, step=100, precision=1, update=_update_right_rot)
    cam_rx_left:  FloatProperty(name="Pitch Left Rx",  default=90.0, min=-180.0, max=180.0, step=100, precision=1, update=_update_left_rot,  description="Rotation around local X axis – Left camera")
    cam_rx_right: FloatProperty(name="Pitch Right Rx", default=90.0, min=-180.0, max=180.0, step=100, precision=1, update=_update_right_rot, description="Rotation around local X axis – Right camera")
    cam_ry_left:  FloatProperty(name="Yaw Left Ry",    default=0.0,  min=-180.0, max=180.0, step=100, precision=1, update=_update_left_rot,  description="Rotation around local Y axis – Left camera")
    cam_ry_right: FloatProperty(name="Yaw Right Ry",   default=0.0,  min=-180.0, max=180.0, step=100, precision=1, update=_update_right_rot, description="Rotation around local Y axis – Right camera")

    # [A] Shift X/Y working values per camera – live update
    cam_sx_left:  FloatProperty(name="Shift X", default=-0.08849, min=-5.0, max=5.0, step=1, precision=4, update=_update_shift_left,  description="Left  – principal point offset X (Blender convention)")
    cam_sy_left:  FloatProperty(name="Shift Y", default=-0.07444, min=-5.0, max=5.0, step=1, precision=4, update=_update_shift_left,  description="Left  – principal point offset Y (Blender convention)")
    cam_sx_right: FloatProperty(name="Shift X", default=-0.06449, min=-5.0, max=5.0, step=1, precision=4, update=_update_shift_right, description="Right – principal point offset X (Blender convention)")
    cam_sy_right: FloatProperty(name="Shift Y", default= 0.04153, min=-5.0, max=5.0, step=1, precision=4, update=_update_shift_right, description="Right – principal point offset Y (Blender convention)")

    # [A] Base shift values (from calibration) – source for scaling
    cam_sx0_left:  FloatProperty(default=-0.88492)
    cam_sy0_left:  FloatProperty(default=-0.74436)
    cam_sx0_right: FloatProperty(default=-0.64492)
    cam_sy0_right: FloatProperty(default= 0.41528)

    # [A] Global Shift X/Y scale slider
    cam_shift_scale: FloatProperty(
        name="Shift X/Y Scale",
        description=(
            "Proportional scaling of principal point offset\n"
            "for both cameras simultaneously.\n"
            "0.00 = no offset  |  1.00 = full calibration value"
        ),
        default=0.10, min=0.00, max=1.00,
        step=1, precision=2,
        update=_update_shift_scale,
    )

    # Camera display parameters
    cam_display_size: FloatProperty(name="Camera display size [m]", default=0.05, min=0.005, max=1.0)
    cam_focal_length: FloatProperty(
        name="Focal Length [mm]",
        description="Focal length for all Raven cameras – updates live in viewport",
        default=13.55, min=1.0, max=300.0, step=10, precision=2,
        update=_update_focal_length,
    )

    # [B] Background alpha – live update
    cam_bg_alpha: FloatProperty(
        name="Background Alpha",
        description="Background image opacity – updates all Raven cameras live",
        default=0.5, min=0.0, max=1.0,
        update=_update_bg_alpha,
    )

    # [C] COLMAP import
    colmap_images_path: StringProperty(
        name="COLMAP images.txt",
        description="Path to COLMAP images.txt – camera poses matched by numeric timestamp",
        subtype='FILE_PATH', default="",
    )

    # COLMAP export
    export_dir:    StringProperty(name="Export directory", subtype='DIR_PATH', default="")
    export_images: BoolProperty(
        name="Copy images",
        description="Copy assigned images to 'images' subdirectory",
        default=False,
    )


# ════════════════════════════════════════════════════════════════
#  OPERATOR – DRAW PATH
# ════════════════════════════════════════════════════════════════

class Raven_OT_DrawPath(Operator):
    """Load trajectory file and draw path polyline"""
    bl_idname  = "raven.drawpath"
    bl_label   = "Draw trajectory path"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.raventraj
        if not os.path.isfile(props.trjfilepath):
            self.report({'ERROR'}, f"File not found: {props.trjfilepath}")
            return {'CANCELLED'}
        records = load_trajectory(props.trjfilepath, step=props.step)
        if not records:
            self.report({'ERROR'}, "Trajectory file is empty or invalid.")
            return {'CANCELLED'}

        for o in list(bpy.data.objects):
            if o.name == "RavenPath":
                bpy.data.objects.remove(o, do_unlink=True)
        for m in list(bpy.data.meshes):
            if m.name == "RavenPathMesh":
                bpy.data.meshes.remove(m)

        verts = [(r['pos'].x, r['pos'].y, r['pos'].z) for r in records]
        edges = [(i, i+1) for i in range(len(verts)-1)]
        mesh  = bpy.data.meshes.new("RavenPathMesh")
        mesh.from_pydata(verts, edges, [])
        mesh.update()
        obj       = bpy.data.objects.new("RavenPath", mesh)
        obj.color = (0.0, 0.8, 1.0, 1.0)
        get_or_create_collection("RavenTrajectory").objects.link(obj)

        full = load_trajectory(props.trjfilepath, step=1)
        context.scene['raventrjdata'] = [
            [r['ts'], r['pos'].x, r['pos'].y, r['pos'].z,
             r['quat'].x, r['quat'].y, r['quat'].z, r['quat'].w]
            for r in full
        ]
        self.report({'INFO'},
            f"Loaded {len(records)} path points / {len(full)} for interpolation.")
        return {'FINISHED'}


# ════════════════════════════════════════════════════════════════
#  OPERATOR – INSERT CAMERAS (from trajectory)
# ════════════════════════════════════════════════════════════════

class Raven_OT_InsertCameras(Operator):
    """Insert Blender cameras at interpolated positions from image timestamps"""
    bl_idname  = "raven.insertcameras"
    bl_label   = "Insert cameras from image timestamps"
    bl_options = {'REGISTER', 'UNDO'}

    def _prepare_calib(self, context):
        props = context.scene.raventraj
        if props.calibfilepath and os.path.isfile(props.calibfilepath):
            try:
                return load_calib(props.calibfilepath)
            except Exception as e:
                self.report({'WARNING'}, f"Error in calib.json: {e}. Using built-in defaults.")
        return DEFAULT_CALIB

    def _init_shift_from_calib(self, props, calib):
        scale = props.cam_shift_scale
        for side in ('left', 'right'):
            cd = calib.get(side, DEFAULT_CALIB[side])
            sx0, sy0 = calib_to_shift(cd)
            setattr(props, f'cam_sx0_{side}', sx0)
            setattr(props, f'cam_sy0_{side}', sy0)
            setattr(props, f'cam_sx_{side}',  sx0 * scale)
            setattr(props, f'cam_sy_{side}',  sy0 * scale)

    def execute(self, context):
        props = context.scene.raventraj

        raw = context.scene.get('raventrjdata')
        if raw:
            records = [
                {'ts':   row[0],
                 'pos':  Vector(row[1:4]),
                 'quat': Quaternion((row[7], row[4], row[5], row[6]))}
                for row in raw
            ]
        elif os.path.isfile(props.trjfilepath):
            records = load_trajectory(props.trjfilepath, step=1)
        else:
            self.report({'ERROR'}, "No trajectory data – click 'Draw trajectory path' first.")
            return {'CANCELLED'}
        if not records:
            self.report({'ERROR'}, "No trajectory points found.")
            return {'CANCELLED'}

        calib = self._prepare_calib(context)
        self._init_shift_from_calib(props, calib)

        tasks = []
        if props.draw_imu_left and props.folder_left:
            imgs = collect_image_timestamps(props.folder_left)
            tasks.extend(('left', ts, fp) for ts, fp in imgs[::props.imgstep])
        if props.draw_imu_right and props.folder_right:
            imgs = collect_image_timestamps(props.folder_right)
            tasks.extend(('right', ts, fp) for ts, fp in imgs[::props.imgstep])

        if not tasks:
            self.report({'WARNING'}, "No images found – check Left/Right folders.")
            return {'CANCELLED'}

        coll = get_or_create_collection("RavenCAMLeft")
        colr = get_or_create_collection("RavenCAMRight")
        clear_collection(coll)
        clear_collection(colr)
        for cam in list(bpy.data.cameras):
            if cam.name.startswith(('CAML', 'CAMR')):
                bpy.data.cameras.remove(cam)

        inserted = skipped = 0

        for side, ts, filepath in tasks:
            result = interpolate_pose(records, ts)
            if result is None:
                skipped += 1
                continue
            pos, quat = result

            Mimu    = imu_world_matrix(pos, quat,
                                       props.imurx, props.imury, props.imurz)
            cam_cd  = calib.get(side, DEFAULT_CALIB.get(side, {}))
            Tcvlist = cam_cd.get('transformmatrix',
                                  DEFAULT_CALIB[side]['transformmatrix'])
            M_base  = cam_base_matrix(Mimu, Tcvlist)

            rz = getattr(props, f'cam_rz_{side}')
            rx = getattr(props, f'cam_rx_{side}')
            ry = getattr(props, f'cam_ry_{side}')
            Mfinal = _apply_local_corrections(M_base, rz, rx, ry)

            sx = getattr(props, f'cam_sx_{side}')
            sy = getattr(props, f'cam_sy_{side}')

            prefix  = "CAML" if side == 'left' else "CAMR"
            camname = f"{prefix}{ts:.3f}"

            camobj = create_blender_camera(
                camname, Mfinal, M_base, calib, side,
                shift_x=sx, shift_y=sy,
                focal_length_override=props.cam_focal_length,
            )
            camobj.data.display_size = props.cam_display_size
            camobj.color = (0.0, 0.4, 1.0, 1.0) if side == 'left' else (1.0, 0.55, 0.0, 1.0)
            camobj['jmk6image']     = os.path.basename(filepath)
            camobj['jmk6timestamp'] = ts
            camobj['jmk6side']      = side
            camobj['jmk6src_path']  = filepath

            target_col = coll if side == 'left' else colr
            for c in list(camobj.users_collection):
                c.objects.unlink(camobj)
            target_col.objects.link(camobj)
            inserted += 1

        context.scene.unit_settings.system       = 'METRIC'
        context.scene.unit_settings.scale_length = 1.0
        context.scene.unit_settings.length_unit  = 'METERS'

        self.report({'INFO'},
            f"Inserted {inserted} cameras, skipped {skipped} (out of trajectory range).")
        return {'FINISHED'}


# ════════════════════════════════════════════════════════════════
#  OPERATOR – INSERT CAMERAS FROM COLMAP images.txt
# ════════════════════════════════════════════════════════════════

class Raven_OT_InsertCamerasFromCOLMAP(Operator):
    """
    Insert Left/Right cameras from COLMAP images.txt.
    Camera poses taken directly from images.txt (world->camera CV) – no IMU involved.
    Images matched to cameras by numeric timestamp value extracted from filename.
    Images without a match in Folder Left/Right are skipped.
    """
    bl_idname  = "raven.insert_from_colmap"
    bl_label   = "Insert cameras from COLMAP images.txt"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.raventraj

        if not props.colmap_images_path or not os.path.isfile(props.colmap_images_path):
            self.report({'ERROR'}, "Please select a valid COLMAP images.txt file.")
            return {'CANCELLED'}

        colmap_data = parse_colmap_images(props.colmap_images_path)
        if not colmap_data:
            self.report({'ERROR'}, "No entries found in images.txt or invalid format.")
            return {'CANCELLED'}

        if props.calibfilepath and os.path.isfile(props.calibfilepath):
            try:
                calib = load_calib(props.calibfilepath)
            except Exception as e:
                self.report({'WARNING'}, f"Error in calib.json: {e}. Using built-in defaults.")
                calib = DEFAULT_CALIB
        else:
            calib = DEFAULT_CALIB

        scale = props.cam_shift_scale
        for side in ('left', 'right'):
            cd       = calib.get(side, DEFAULT_CALIB[side])
            sx0, sy0 = calib_to_shift(cd)
            setattr(props, f'cam_sx0_{side}', sx0)
            setattr(props, f'cam_sy0_{side}', sy0)
            setattr(props, f'cam_sx_{side}',  sx0 * scale)
            setattr(props, f'cam_sy_{side}',  sy0 * scale)

        folder_imgs = {}
        for side, folder in (('left', props.folder_left), ('right', props.folder_right)):
            if not folder:
                continue
            for ts, fp in collect_image_timestamps(folder):
                folder_imgs[ts] = (side, fp)

        if not folder_imgs:
            self.report({'WARNING'}, "No images found – check Folder Left/Right.")
            return {'CANCELLED'}

        coll = get_or_create_collection("RavenCAMLeft")
        colr = get_or_create_collection("RavenCAMRight")
        clear_collection(coll)
        clear_collection(colr)
        for cam in list(bpy.data.cameras):
            if cam.name.startswith(('CAML', 'CAMR')):
                bpy.data.cameras.remove(cam)

        inserted = skipped_no_img = 0

        for ts_colmap, (qw, qx, qy, qz, tx, ty, tz, cam_id, name) in sorted(colmap_data.items()):
            if ts_colmap not in folder_imgs:
                skipped_no_img += 1
                continue

            side, filepath = folder_imgs[ts_colmap]
            Mworld = colmap_to_blender_world(qw, qx, qy, qz, tx, ty, tz)
            M_base = Mworld.copy()

            rz = getattr(props, f'cam_rz_{side}')
            rx = getattr(props, f'cam_rx_{side}')
            ry = getattr(props, f'cam_ry_{side}')
            Mfinal = _apply_local_corrections(M_base, rz, rx, ry)

            sx = getattr(props, f'cam_sx_{side}')
            sy = getattr(props, f'cam_sy_{side}')

            prefix  = "CAML" if side == 'left' else "CAMR"
            camname = f"{prefix}{ts_colmap:.3f}"

            camobj = create_blender_camera(
                camname, Mfinal, M_base, calib, side,
                shift_x=sx, shift_y=sy,
                focal_length_override=props.cam_focal_length,
            )
            camobj.data.display_size = props.cam_display_size
            camobj.color = (0.0, 0.4, 1.0, 1.0) if side == 'left' else (1.0, 0.55, 0.0, 1.0)
            camobj['jmk6image']     = os.path.basename(filepath)
            camobj['jmk6timestamp'] = ts_colmap
            camobj['jmk6side']      = side
            camobj['jmk6src_path']  = filepath
            camobj['ravencolmap']   = True

            target_col = coll if side == 'left' else colr
            for c in list(camobj.users_collection):
                c.objects.unlink(camobj)
            target_col.objects.link(camobj)
            inserted += 1

        context.scene.unit_settings.system       = 'METRIC'
        context.scene.unit_settings.scale_length = 1.0
        context.scene.unit_settings.length_unit  = 'METERS'

        self.report({'INFO'},
            f"COLMAP: inserted {inserted} cameras | "
            f"skipped (no matching image): {skipped_no_img}")
        return {'FINISHED'}


# ════════════════════════════════════════════════════════════════
#  OPERATOR – LOAD BACKGROUND IMAGES  [1]
# ════════════════════════════════════════════════════════════════

class Raven_OT_LoadBgImages(Operator):
    """
    Load images from Folder Left and Folder Right as Background Images
    for all matching Raven cameras. Matches by numeric timestamp in filename.
    Does not reload images that are already assigned.
    """
    bl_idname  = "raven.load_bg_images"
    bl_label   = "Load Background Images"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.raventraj
        alpha = props.cam_bg_alpha

        # Build timestamp→filepath map from both folders
        folder_imgs = {}
        for folder in (props.folder_left, props.folder_right):
            if not folder:
                continue
            for ts, fp in collect_image_timestamps(folder):
                folder_imgs[ts] = fp

        if not folder_imgs:
            self.report({'WARNING'}, "No images found – check Folder Left/Right.")
            return {'CANCELLED'}

        loaded = skipped = already = 0
        for obj in bpy.data.objects:
            if obj.type != 'CAMERA' or not obj.name.startswith(('CAML', 'CAMR')):
                continue
            ts = obj.get('jmk6timestamp')
            if ts is None:
                skipped += 1
                continue
            filepath = folder_imgs.get(float(ts))
            if filepath is None:
                skipped += 1
                continue

            cd = obj.data
            # Skip if already has a background image assigned
            if cd.background_images:
                already += 1
                continue

            img                            = bpy.data.images.load(filepath, check_existing=True)
            bg                             = cd.background_images.new()
            bg.image                       = img
            bg.alpha                       = alpha
            bg.display_depth               = 'BACK'
            bg.source                      = 'IMAGE'
            cd.show_background_images      = True
            loaded += 1

        msg = f"Background images: loaded {loaded}"
        if already:
            msg += f", already assigned {already}"
        if skipped:
            msg += f", no match {skipped}"
        self.report({'INFO'}, msg)
        return {'FINISHED'}


# ════════════════════════════════════════════════════════════════
#  OPERATOR – EXPORT COLMAP
# ════════════════════════════════════════════════════════════════

class Raven_OT_ExportCOLMAP(Operator):
    """Export Raven cameras to COLMAP format (images.txt, cameras.txt)"""
    bl_idname  = "raven.export_colmap"
    bl_label   = "Export to COLMAP"
    bl_options = {'REGISTER'}

    def _blender_to_colmap(self, obj):
        M     = obj.matrix_world
        C_CV  = Matrix(((1, 0, 0), (0, -1, 0), (0, 0, -1)))
        R_w2c = (M.to_3x3() @ C_CV).transposed()
        t     = R_w2c @ (-M.translation)
        q     = R_w2c.to_quaternion()
        return q, t

    def execute(self, context):
        props   = context.scene.raventraj
        out_dir = bpy.path.abspath(props.export_dir)
        if not out_dir:
            self.report({'ERROR'}, "Please select an export directory.")
            return {'CANCELLED'}
        os.makedirs(out_dir, exist_ok=True)

        cams_left = sorted(
            [o for o in bpy.data.objects if o.type == 'CAMERA' and o.name.startswith('CAML')],
            key=lambda o: o.get('jmk6timestamp', 0.0),
        )
        cams_right = sorted(
            [o for o in bpy.data.objects if o.type == 'CAMERA' and o.name.startswith('CAMR')],
            key=lambda o: o.get('jmk6timestamp', 0.0),
        )
        all_cams = cams_left + cams_right

        if not all_cams:
            self.report({'ERROR'}, "No Raven cameras found in scene.")
            return {'CANCELLED'}

        img_lines = [
            "# Image list with two lines of data per image:\n",
            "# IMAGE_ID, QW, QX, QY, QZ, TX, TY, TZ, CAMERA_ID, NAME\n",
        ]
        for img_id, obj in enumerate(all_cams, start=1):
            q, t   = self._blender_to_colmap(obj)
            side   = obj.get('jmk6side', 'left')
            cam_id = 1 if side == 'left' else 2
            name   = obj.get('jmk6image', f"frame_{img_id:04d}.png")
            img_lines.append(
                f"{img_id} "
                f"{q.w:.6f} {q.x:.6f} {q.y:.6f} {q.z:.6f} "
                f"{t.x:.6f} {t.y:.6f} {t.z:.6f} "
                f"{cam_id} {name}\n"
            )
            img_lines.append("0.0 0.0 -1\n")

        with open(os.path.join(out_dir, "images.txt"), 'w') as f:
            f.writelines(img_lines)

        def get_img_size(cam_list):
            for obj in cam_list:
                for bg in obj.data.background_images:
                    if bg.image and bg.image.size[0] > 0:
                        return int(bg.image.size[0]), int(bg.image.size[1])
                w = int(obj.data.get('calib_w', 0))
                h = int(obj.data.get('calib_h', 0))
                if w and h:
                    return w, h
            return 750, 1000

        def pinhole_params(cam_list, w, h):
            if cam_list:
                cd = cam_list[0].data
                sw = cd.sensor_width if cd.sensor_width > 0 else 36.0
                fx = cd.lens * w / sw
                fy = cd.lens * h / sw
                cx = (cd.shift_x + 0.5) * w
                cy = (0.5 - cd.shift_y) * h
                return fx, fy, cx, cy
            return 281.445, 281.708, 393.208, 487.762

        wL, hL = get_img_size(cams_left)
        wR, hR = get_img_size(cams_right)
        fxL, fyL, cxL, cyL = pinhole_params(cams_left,  wL, hL)
        fxR, fyR, cxR, cyR = pinhole_params(cams_right, wR, hR)

        cam_lines = [
            "# Camera list with one line of data per camera:\n",
            "# CAMERA_ID, MODEL, WIDTH, HEIGHT, PARAMS[]\n",
            f"1 PINHOLE {wL} {hL} {fxL:.3f} {fyL:.3f} {cxL:.3f} {cyL:.3f}\n",
            f"2 PINHOLE {wR} {hR} {fxR:.3f} {fyR:.3f} {cxR:.3f} {cyR:.3f}\n",
        ]
        with open(os.path.join(out_dir, "cameras.txt"), 'w') as f:
            f.writelines(cam_lines)

        copied = 0
        if props.export_images:
            img_dir = os.path.join(out_dir, "images")
            os.makedirs(img_dir, exist_ok=True)
            for obj in all_cams:
                src  = obj.get('jmk6src_path', '')
                name = obj.get('jmk6image', '')
                if src and os.path.isfile(src) and name:
                    dst = os.path.join(img_dir, name)
                    if not os.path.exists(dst):
                        shutil.copy2(src, dst)
                    copied += 1

        msg = (f"Exported {len(all_cams)} cameras → {out_dir}"
               + (f" | copied {copied} images" if props.export_images else ""))
        self.report({'INFO'}, msg)
        return {'FINISHED'}


# ════════════════════════════════════════════════════════════════
#  OPERATORS – CAMERA CONTROLS
# ════════════════════════════════════════════════════════════════

class Raven_OT_MatchResolution(Operator):
    """Set scene resolution to match the active Raven camera"""
    bl_idname  = "raven.matchresolution"
    bl_label   = "Match scene proportions to image"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if obj is None or obj.type != 'CAMERA':
            self.report({'ERROR'}, "Select a Raven camera as the active object.")
            return {'CANCELLED'}
        cd   = obj.data
        w, h = None, None
        for bg in cd.background_images:
            if bg.image and bg.image.size[0] > 0:
                w, h = int(bg.image.size[0]), int(bg.image.size[1])
                break
        if w is None:
            w = int(cd.get('calib_w', 0))
            h = int(cd.get('calib_h', 0))
        if not w or not h:
            self.report({'WARNING'}, "No background image and no calibration data found.")
            return {'CANCELLED'}
        sc = context.scene
        sc.render.resolution_x          = w
        sc.render.resolution_y          = h
        sc.render.resolution_percentage = 100
        cd.sensor_fit = 'HORIZONTAL' if w >= h else 'VERTICAL'
        self.report({'INFO'}, f"Scene: {w} × {h} px")
        return {'FINISHED'}


class Raven_OT_ViewFromCamera(Operator):
    """Switch 3D viewport to look through the active Raven camera"""
    bl_idname  = "raven.viewfromcamera"
    bl_label   = "View from active camera"
    bl_options = {'REGISTER'}

    def execute(self, context):
        obj = context.active_object
        if obj is None or obj.type != 'CAMERA':
            self.report({'ERROR'}, "Select a Raven camera as the active object.")
            return {'CANCELLED'}
        context.scene.camera = obj
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        space.region_3d.view_perspective = 'CAMERA'
                break
        self.report({'INFO'}, f"View from: {obj.name}")
        return {'FINISHED'}


class Raven_OT_ToggleBgDepth(Operator):
    """
    Toggle display_depth of background images across all Raven cameras
    between BACK and FRONT. Current state read from first camera found.
    Default: BACK.
    """
    bl_idname  = "raven.toggle_bg_depth"
    bl_label   = "Toggle BG Depth (BACK ↔ FRONT)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        cams = [o for o in bpy.data.objects
                if o.type == 'CAMERA' and o.name.startswith(('CAML', 'CAMR'))]
        if not cams:
            self.report({'WARNING'}, "No Raven cameras in scene.")
            return {'CANCELLED'}

        current = 'BACK'
        for obj in cams:
            if obj.data.background_images:
                current = obj.data.background_images[0].display_depth
                break

        new_depth = 'FRONT' if current == 'BACK' else 'BACK'
        updated   = 0
        for obj in cams:
            for bg in obj.data.background_images:
                bg.display_depth = new_depth
                updated += 1

        self.report({'INFO'}, f"BG Depth → {new_depth}  ({updated} images updated)")
        return {'FINISHED'}


class Raven_OT_CreateAnimation(Operator):
    """Generate animation from Raven cameras using Bind Camera to Markers"""
    bl_idname  = "raven.createanimation"
    bl_label   = "Generate animation from cameras"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        sc         = context.scene
        cams_left  = sorted(
            [o for o in bpy.data.objects if o.type == 'CAMERA' and o.name.startswith('CAML')],
            key=lambda o: o.get('jmk6timestamp', 0.0),
        )
        cams_right = sorted(
            [o for o in bpy.data.objects if o.type == 'CAMERA' and o.name.startswith('CAMR')],
            key=lambda o: o.get('jmk6timestamp', 0.0),
        )
        all_cams = cams_left + cams_right
        if not all_cams:
            self.report({'ERROR'}, "No Raven cameras found in scene.")
            return {'CANCELLED'}

        for m in [m for m in sc.timeline_markers if m.name.startswith("Raven")]:
            sc.timeline_markers.remove(m)
        sc.frame_start = 1
        sc.frame_end   = len(all_cams)

        for frame_idx, camobj in enumerate(all_cams, start=1):
            side   = camobj.get('jmk6side', '?').upper()
            marker = sc.timeline_markers.new(f"Raven{side}{frame_idx:04d}", frame=frame_idx)
            marker.camera = camobj

        sc.camera = all_cams[0]
        self.report({'INFO'},
            f"Animation: {len(cams_left)} frames L + {len(cams_right)} frames R "
            f"= {len(all_cams)} total.")
        return {'FINISHED'}


class Raven_OT_ClearAll(Operator):
    """Remove all Raven objects (cameras, path, collections) from the scene"""
    bl_idname  = "raven.clearall"
    bl_label   = "Clear Raven scene"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        removed = 0
        for obj in list(bpy.data.objects):
            if obj.name.startswith(('Raven', 'CAML', 'CAMR')):
                bpy.data.objects.remove(obj, do_unlink=True)
                removed += 1
        for mesh in list(bpy.data.meshes):
            if mesh.name.startswith('Raven'):
                bpy.data.meshes.remove(mesh)
        for cam in list(bpy.data.cameras):
            if cam.name.startswith(('CAML', 'CAMR')):
                bpy.data.cameras.remove(cam)
        for col in list(bpy.data.collections):
            if col.name.startswith('Raven'):
                bpy.data.collections.remove(col)
        for m in [m for m in context.scene.timeline_markers if m.name.startswith('Raven')]:
            context.scene.timeline_markers.remove(m)
        if 'raventrjdata' in context.scene:
            del context.scene['raventrjdata']
        self.report({'INFO'}, f"Removed {removed} Raven objects from scene.")
        return {'FINISHED'}


# ════════════════════════════════════════════════════════════════
#  PANEL
# ════════════════════════════════════════════════════════════════

class Raven_PT_MainPanel(Panel):
    bl_label       = "Raven Trajectory"
    bl_idname      = "RAVEN_PT_main"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "Raven Traj"

    def draw(self, context):
        layout = self.layout
        props  = context.scene.raventraj

        # 1. Input files
        box = layout.box()
        box.label(text="Input files", icon='FILE_FOLDER')
        box.prop(props, "trjfilepath",   text="Trajectory .txt")
        box.prop(props, "calibfilepath", text="Calib .json – optional")

        # 2. Trajectory path
        box2 = layout.box()
        box2.label(text="Trajectory path", icon='CURVE_PATH')
        box2.prop(props, "step", text="Every Nth point")
        box2.operator("raven.drawpath", icon='PLAY')

        # 3. IMU orientation correction
        box3 = layout.box()
        box3.label(text="IMU orientation correction", icon='ORIENTATION_GIMBAL')
        box3.label(text="R_bl = R_quat · Rx · Ry · Rz", icon='INFO')
        row = box3.row(align=True)
        row.prop(props, "imurx")
        row.prop(props, "imury")
        row.prop(props, "imurz")
        sub = box3.column(align=True)
        sub.scale_y = 0.75
        sub.label(text="Rx – tilt")
        sub.label(text="Ry – front/back (180° reverses Y)")
        sub.label(text="Rz – horizontal rotation")

        # 4. Cameras from image timestamps
        box4 = layout.box()
        box4.label(text="Cameras from image timestamps", icon='CAMERA_DATA')
        row = box4.row()
        row.prop(props, "draw_imu_left")
        row.prop(props, "draw_imu_right")
        box4.prop(props, "folder_left",  text="Folder Left")
        box4.prop(props, "folder_right", text="Folder Right")
        box4.prop(props, "imgstep", text="Every Nth image")

        # Local corrections Rz/Rx/Ry
        box4.separator(factor=0.5)
        box4.label(text="Local camera corrections (live):", icon='CON_ROTLIKE')
        sub_rz = box4.column(align=True)
        sub_rz.label(text="Roll (Rz):")
        row_rz = sub_rz.row(align=True)
        row_rz.prop(props, "cam_rz_left",  text="Left")
        row_rz.prop(props, "cam_rz_right", text="Right")
        sub_rx = box4.column(align=True)
        sub_rx.label(text="Pitch (Rx):")
        row_rx = sub_rx.row(align=True)
        row_rx.prop(props, "cam_rx_left",  text="Left")
        row_rx.prop(props, "cam_rx_right", text="Right")
        sub_ry = box4.column(align=True)
        sub_ry.label(text="Yaw (Ry):")
        row_ry = sub_ry.row(align=True)
        row_ry.prop(props, "cam_ry_left",  text="Left")
        row_ry.prop(props, "cam_ry_right", text="Right")

        # Shift X/Y per camera
        box4.separator(factor=0.5)
        box4.label(text="Shift X/Y (principal point):", icon='DRIVER_TRANSFORM')
        sub_sl = box4.box()
        sub_sl.scale_y = 0.85
        sub_sl.label(text="Left  (blue)")
        row_sl = sub_sl.row(align=True)
        row_sl.prop(props, "cam_sx_left",  text="Shift X")
        row_sl.prop(props, "cam_sy_left",  text="Shift Y")
        sub_sr = box4.box()
        sub_sr.scale_y = 0.85
        sub_sr.label(text="Right (orange)")
        row_sr = sub_sr.row(align=True)
        row_sr.prop(props, "cam_sx_right", text="Shift X")
        row_sr.prop(props, "cam_sy_right", text="Shift Y")

        # Global Shift X/Y scale
        box_sc = box4.box()
        box_sc.label(text="Global Shift X/Y scale:", icon='DRIVER_TRANSFORM')
        box_sc.prop(props, "cam_shift_scale", slider=True,
                    text="Scale  0.00 = none  |  1.00 = full calib")
        col_info = box_sc.column(align=True)
        col_info.scale_y = 0.7
        scale = props.cam_shift_scale
        for side in ('left', 'right'):
            sx0 = getattr(props, f'cam_sx0_{side}')
            sy0 = getattr(props, f'cam_sy0_{side}')
            col_info.label(
                text=f"  {side:<5}  sx={sx0*scale:+.4f}  sy={sy0*scale:+.4f}",
                icon='BLANK1',
            )

        box4.separator(factor=0.5)
        box4.prop(props, "cam_display_size",  text="Camera display size [m]")
        box4.prop(props, "cam_focal_length",  text="Focal Length [mm]")
        box4.operator("raven.insertcameras", icon='OBJECT_ORIGIN')

        # 4b. COLMAP import
        box4c = layout.box()
        box4c.label(text="Import cameras from COLMAP", icon='IMPORT')
        box4c.prop(props, "colmap_images_path", text="images.txt")
        sub4c = box4c.column(align=True)
        sub4c.scale_y = 0.75
        sub4c.label(text="Poses: directly from images.txt (no IMU)", icon='INFO')
        sub4c.label(text="Match by numeric timestamp (10+6 digits)")
        sub4c.label(text="Folders Left/Right: as set in section 4 above")
        box4c.operator("raven.insert_from_colmap", icon='OBJECT_ORIGIN')

        # 5. Rendering & Background Images
        box5 = layout.box()
        box5.label(text="Rendering & Background Images", icon='SCENE')
        sc = context.scene
        box5.label(text=f"Scene: {sc.render.resolution_x} × {sc.render.resolution_y} px",
                   icon='INFO')
        act = context.active_object
        if act and act.type == 'CAMERA':
            cd = act.data
            cw = int(cd.get('calib_w', 0))
            ch = int(cd.get('calib_h', 0))
            if cw and ch:
                box5.label(text=f"Calibration: {cw} × {ch} px", icon='CAMERA_DATA')
            for bg in cd.background_images:
                if bg.image and bg.image.size[0] > 0:
                    iw, ih = int(bg.image.size[0]), int(bg.image.size[1])
                    box5.label(text=f"Background image: {iw} × {ih} px", icon='IMAGE_DATA')
                    break
            box5.label(
                text=f"shift_x={cd.shift_x:.4f}  shift_y={cd.shift_y:.4f}",
                icon='DRIVER_TRANSFORM',
            )
        # [1] Load Background Images button – above Match Resolution
        box5.operator("raven.load_bg_images", icon='IMAGE_BACKGROUND')
        box5.operator("raven.matchresolution", icon='FULLSCREEN_ENTER')

        # 5b. Camera controls
        box5b = layout.box()
        box5b.label(text="Camera controls", icon='TOOL_SETTINGS')
        col_fl = box5b.column(align=True)
        col_fl.prop(props, "cam_focal_length", text="Focal Length [mm]")
        sub_fl = col_fl.row()
        sub_fl.scale_y = 0.65
        sub_fl.label(text="↑ updates all cameras live", icon='INFO')
        box5b.operator("raven.viewfromcamera", icon='OUTLINER_OB_CAMERA')

        # [B] Alpha live slider + Toggle BG Depth
        row_al = box5b.row(align=True)
        row_al.prop(props, "cam_bg_alpha", text="Background alpha", slider=True)
        row_al.operator("raven.toggle_bg_depth", text="", icon='IMAGE_ZDEPTH')
        sub_al = box5b.row()
        sub_al.scale_y = 0.65
        sub_al.label(text="Alpha: live  |  Button: Toggle BACK ↔ FRONT depth", icon='INFO')
        box5b.separator()
        box5b.operator("raven.createanimation", icon='RENDER_ANIMATION')

        # 6. COLMAP export
        box6 = layout.box()
        box6.label(text="Export COLMAP", icon='EXPORT')
        box6.prop(props, "export_dir",    text="Directory")
        box6.prop(props, "export_images", text="Copy images to images/")
        sub6 = box6.column(align=True)
        sub6.scale_y = 0.8
        sub6.label(text="Generates: images.txt  cameras.txt", icon='INFO')
        sub6.label(text="Left → CAMERA_ID 1  |  Right → CAMERA_ID 2")
        box6.operator("raven.export_colmap", icon='EXPORT')

        # 7. Clear scene
        layout.separator()
        layout.operator("raven.clearall", icon='TRASH')


# ════════════════════════════════════════════════════════════════
#  REGISTRATION
# ════════════════════════════════════════════════════════════════

_classes = (
    RavenTrajProperties,
    Raven_OT_DrawPath,
    Raven_OT_InsertCameras,
    Raven_OT_InsertCamerasFromCOLMAP,
    Raven_OT_LoadBgImages,
    Raven_OT_ExportCOLMAP,
    Raven_OT_MatchResolution,
    Raven_OT_ViewFromCamera,
    Raven_OT_ToggleBgDepth,
    Raven_OT_CreateAnimation,
    Raven_OT_ClearAll,
    Raven_PT_MainPanel,
)

def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.raventraj = PointerProperty(type=RavenTrajProperties)

def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.raventraj

if __name__ == "__main__":
    register()
